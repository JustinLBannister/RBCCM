<?xml version="1.0" encoding="UTF-8"?>
<!--
  RBCCM Hero :: strategy-and-economics (single-skin build)
  ==============================================================
  Standalone XSL skin for TeamSite's Skin dropdown. Renders ONLY
  the Strategy & Economics variant of rbccm-hero. No Preset
  branching - the variant class is hardcoded below.

  Structure: split 2-column grid, optional Brightcove video
  backdrop + blur ellipse, dark-navy "Latest insight" card on
  the right. Above-the-fold reveal fires immediately on page
  load; insight card follows at 325ms.

  Insight sourcing modes:
    dcr-picker   Server-rendered from a picked DCR record
                 (SeInsight* Datums act as per-field overrides).
    auto-latest  Hydrator overwrites the pre-render at runtime
                 with the newest matching feed record.
    manual       Fully server-rendered from SeInsight* Datums.

  Companion skins: rbccm-hero (double-dash) maas-mata.xsl,
                   rbccm-hero (double-dash) us-credentials.xsl
  Fields: see rbccm-hero-properties.xml (shared by all three skins).
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:output method="html" indent="no" omit-xml-declaration="yes"/>

  <!-- Tag allow-list guard. -->
  <!-- Rich text output. Text pasted into the editor straight from Figma
       carries two hidden spans (data-metadata="(figmeta)..." and
       data-buffer="(figma)...") holding the Figma file key and a base64
       copy of the design, often tens of KB per field. They are invisible
       but bloat the page and expose internal file details, so they are
       removed here; all other HTML is output as entered. -->
  <xsl:template name="rbccmRich">
    <xsl:param name="s"/>
    <xsl:variable name="clean"><xsl:call-template name="rbccmStripFigma"><xsl:with-param name="s" select="string($s)"/></xsl:call-template></xsl:variable>
    <xsl:value-of select="$clean" disable-output-escaping="yes"/>
  </xsl:template>

  <xsl:template name="rbccmStripFigma">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, '&lt;span data-metadata=') and contains(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-metadata='), substring-after(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="contains($s, '&lt;span data-buffer=') and contains(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-buffer='), substring-after(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="pickTag">
    <xsl:param name="raw"/>
    <xsl:param name="default"/>
    <xsl:choose>
      <xsl:when test="$raw = 'h1' or $raw = 'h2' or $raw = 'h3' or $raw = 'h4' or $raw = 'h5' or $raw = 'h6' or $raw = 'p' or $raw = 'div' or $raw = 'span'">
        <xsl:value-of select="$raw"/>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$default"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Format a publishdate string into "July 14, 2025". -->
  <xsl:template name="formatPublishDate">
    <xsl:param name="raw"/>
    <xsl:variable name="d" select="normalize-space($raw)"/>
    <xsl:choose>
      <xsl:when test="contains($d, '-') and string-length($d) >= 10">
        <xsl:variable name="y" select="substring($d, 1, 4)"/>
        <xsl:variable name="m" select="number(substring($d, 6, 2))"/>
        <xsl:variable name="day" select="number(substring($d, 9, 2))"/>
        <xsl:call-template name="monthName"><xsl:with-param name="n" select="$m"/></xsl:call-template>
        <xsl:text> </xsl:text><xsl:value-of select="$day"/>, <xsl:value-of select="$y"/>
      </xsl:when>
      <xsl:when test="string-length($d) = 8 and not(contains($d, '-'))">
        <xsl:variable name="y" select="substring($d, 1, 4)"/>
        <xsl:variable name="m" select="number(substring($d, 5, 2))"/>
        <xsl:variable name="day" select="number(substring($d, 7, 2))"/>
        <xsl:call-template name="monthName"><xsl:with-param name="n" select="$m"/></xsl:call-template>
        <xsl:text> </xsl:text><xsl:value-of select="$day"/>, <xsl:value-of select="$y"/>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$d"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  <xsl:template name="monthName">
    <xsl:param name="n"/>
    <xsl:choose>
      <xsl:when test="$n = 1">January</xsl:when>
      <xsl:when test="$n = 2">February</xsl:when>
      <xsl:when test="$n = 3">March</xsl:when>
      <xsl:when test="$n = 4">April</xsl:when>
      <xsl:when test="$n = 5">May</xsl:when>
      <xsl:when test="$n = 6">June</xsl:when>
      <xsl:when test="$n = 7">July</xsl:when>
      <xsl:when test="$n = 8">August</xsl:when>
      <xsl:when test="$n = 9">September</xsl:when>
      <xsl:when test="$n = 10">October</xsl:when>
      <xsl:when test="$n = 11">November</xsl:when>
      <xsl:when test="$n = 12">December</xsl:when>
    </xsl:choose>
  </xsl:template>


  <!-- Datum lookup with legacy fallback (2026-09 Properties cleanup).
       Reads the new shared ID; if it's blank (or a tag picker is on
       "auto"), falls back to the pre-cleanup per-variant ID so pages
       saved before the cleanup keep rendering. raw=true keeps the
       full un-normalized value (HTML textareas). -->
  <xsl:template name="datumValue">
    <xsl:param name="n"/>
    <xsl:param name="raw" select="false()"/>
    <xsl:variable name="t" select="normalize-space($n[1]/text()[last()])"/>
    <xsl:choose>
      <xsl:when test="$raw"><xsl:value-of select="$n[1]"/></xsl:when>
      <xsl:when test="$t != ''"><xsl:value-of select="$t"/></xsl:when>
      <xsl:otherwise><xsl:value-of select="normalize-space($n[1]/Option[@Selected='true'][1]/Value)"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="datum">
    <xsl:param name="id"/>
    <xsl:param name="legacy" select="''"/>
    <xsl:param name="raw" select="false()"/>
    <xsl:variable name="v">
      <xsl:call-template name="datumValue">
        <xsl:with-param name="n" select="//Datum[@ID=$id]"/>
        <xsl:with-param name="raw" select="$raw"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:choose>
      <xsl:when test="$legacy = '' or (normalize-space($v) != '' and normalize-space($v) != 'auto')">
        <xsl:value-of select="$v"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:call-template name="datumValue">
          <xsl:with-param name="n" select="//Datum[@ID=$legacy]"/>
          <xsl:with-param name="raw" select="$raw"/>
        </xsl:call-template>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>


  <!-- ============================================================
       Insight card character limits
       ============================================================
       SeInsightTitleLimit / SeInsightBodyLimit (plain text):
         default (or blank)  70 for the title, 170 for the body
         full                no limit
         custom=190          that many characters (a bare 190 works too)
       limitValue turns the field into a number; 0 means no limit. -->
  <xsl:template name="limitValue">
    <xsl:param name="raw"/>
    <xsl:param name="default"/>
    <xsl:variable name="v" select="translate(normalize-space($raw), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')"/>
    <xsl:variable name="digits" select="translate($v, translate($v, '0123456789', ''), '')"/>
    <xsl:choose>
      <xsl:when test="$v = 'full'">0</xsl:when>
      <xsl:when test="$digits != ''"><xsl:value-of select="number($digits)"/></xsl:when>
      <xsl:otherwise><xsl:value-of select="$default"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Visible text of a value that may hold HTML (tags stripped). -->
  <xsl:template name="stripTags">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, '&lt;') and contains(substring-after($s, '&lt;'), '&gt;')">
        <xsl:value-of select="substring-before($s, '&lt;')"/>
        <xsl:call-template name="stripTags">
          <xsl:with-param name="s" select="substring-after(substring-after($s, '&lt;'), '&gt;')"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Position of the last space in $s (0 if none). -->
  <xsl:template name="lastSpace">
    <xsl:param name="s"/>
    <xsl:param name="offset" select="0"/>
    <xsl:choose>
      <xsl:when test="contains($s, ' ')">
        <xsl:call-template name="lastSpace">
          <xsl:with-param name="s" select="substring-after($s, ' ')"/>
          <xsl:with-param name="offset" select="$offset + string-length(substring-before($s, ' ')) + 1"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$offset"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Cut $text to at most $max characters including the ellipsis.
       Breaks at the last whole word (unless that would drop more than
       40% of the allowance), trims trailing punctuation, adds an
       ellipsis. $max = 0 or text already short enough: unchanged. -->
  <xsl:template name="truncate">
    <xsl:param name="text"/>
    <xsl:param name="max"/>
    <xsl:variable name="t" select="normalize-space($text)"/>
    <xsl:choose>
      <xsl:when test="$max &lt;= 0 or string-length($t) &lt;= $max"><xsl:value-of select="$t"/></xsl:when>
      <xsl:otherwise>
        <xsl:variable name="cut" select="substring($t, 1, $max - 1)"/>
        <xsl:variable name="sp"><xsl:call-template name="lastSpace"><xsl:with-param name="s" select="$cut"/></xsl:call-template></xsl:variable>
        <xsl:variable name="word">
          <xsl:choose>
            <xsl:when test="$sp &gt; ($max * 0.6)"><xsl:value-of select="substring($cut, 1, $sp - 1)"/></xsl:when>
            <xsl:otherwise><xsl:value-of select="$cut"/></xsl:otherwise>
          </xsl:choose>
        </xsl:variable>
        <xsl:call-template name="trimEnd"><xsl:with-param name="s" select="$word"/></xsl:call-template>
        <xsl:text>&#8230;</xsl:text>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Drop trailing spaces and , ; : . - before the ellipsis. -->
  <xsl:template name="trimEnd">
    <xsl:param name="s"/>
    <xsl:variable name="last" select="substring($s, string-length($s))"/>
    <xsl:choose>
      <xsl:when test="$s != '' and contains(' ,;:.-', $last)">
        <xsl:call-template name="trimEnd"><xsl:with-param name="s" select="substring($s, 1, string-length($s) - 1)"/></xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Breadcrumbs (US Creds, S+E): one Textarea on the Content tab
       (HeroBreadcrumbs) holding just the list items, e.g.
         <li><a href="/en/">Home</a></li><li><a href="/en/about-us">About Us</a></li>
       The skin wraps them in the breadcrumb nav + list; separators are
       drawn in CSS. Blank = no breadcrumbs. Figma spans are stripped like
       the other rich-text fields. -->
  <xsl:template name="heroBreadcrumbs">
    <xsl:variable name="CRUMBS_HTML" select="//Datum[@ID='HeroBreadcrumbs']"/>
    <xsl:if test="normalize-space($CRUMBS_HTML) != ''">
      <!-- The field's rich-text editor wraps the items in its own list
           (<ul><li>...</li></ul>) and adds data-mce-* attributes. The
           skin supplies the <ul>, so the editor's wrapper is unwrapped
           (a <ul> directly inside a <ul> isn't valid) and the editor
           attributes are dropped: only the <li> items go in the list. -->
      <xsl:variable name="CRUMBS_ITEMS">
        <xsl:call-template name="heroCrumbsUnwrap">
          <xsl:with-param name="s" select="normalize-space($CRUMBS_HTML)"/>
        </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="CRUMBS_CLEAN">
        <xsl:call-template name="heroCrumbsStripMce">
          <xsl:with-param name="s" select="string($CRUMBS_ITEMS)"/>
        </xsl:call-template>
      </xsl:variable>
      <nav class="rbccm-hero__breadcrumbs" aria-label="Breadcrumb">
        <ul class="rbccm-hero__breadcrumb-list">
          <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="string($CRUMBS_CLEAN)"/></xsl:call-template>
        </ul>
      </nav>
    </xsl:if>
  </xsl:template>

  <!-- Breadcrumbs: if the field starts with an opening <ul ...> or
       <ol ...>, return just what's inside it (up to its closing tag);
       otherwise return the field as entered. -->
  <xsl:template name="heroCrumbsUnwrap">
    <xsl:param name="s"/>
    <xsl:variable name="head" select="translate(substring($s, 1, 3), 'ULO', 'ulo')"/>
    <xsl:choose>
      <xsl:when test="($head = '&lt;ul' or $head = '&lt;ol') and contains($s, '&gt;')">
        <xsl:variable name="inner" select="substring-after($s, '&gt;')"/>
        <!-- Find the closing tag in a lower-cased copy (so </UL> matches
             too), then cut the original at that position. -->
        <xsl:variable name="innerLc" select="translate($inner, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')"/>
        <xsl:choose>
          <xsl:when test="contains($innerLc, '&lt;/ul&gt;')"><xsl:value-of select="substring($inner, 1, string-length(substring-before($innerLc, '&lt;/ul&gt;')))"/></xsl:when>
          <xsl:when test="contains($innerLc, '&lt;/ol&gt;')"><xsl:value-of select="substring($inner, 1, string-length(substring-before($innerLc, '&lt;/ol&gt;')))"/></xsl:when>
          <xsl:otherwise><xsl:value-of select="$inner"/></xsl:otherwise>
        </xsl:choose>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Breadcrumbs: drop every data-mce-* attribute (name="value") the
       editor adds, e.g. data-mce-href="/en/". -->
  <xsl:template name="heroCrumbsStripMce">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, ' data-mce-')">
        <xsl:variable name="rest" select="substring-after($s, ' data-mce-')"/>
        <xsl:value-of select="substring-before($s, ' data-mce-')"/>
        <xsl:call-template name="heroCrumbsStripMce">
          <xsl:with-param name="s" select="substring-after(substring-after($rest, '&quot;'), '&quot;')"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template match="/">

    <xsl:variable name="SECTION_ID"     select="normalize-space(//Datum[@ID='SectionID']/text()[last()])"/>
    <xsl:variable name="SECTION_ARIA"   select="normalize-space(//Datum[@ID='SectionAriaLabel']/text()[last()])"/>
    <xsl:variable name="CSS_PATH"       select="normalize-space(//Datum[@ID='CssPath']/text()[last()])"/>
    <xsl:variable name="JS_PATH"        select="normalize-space(//Datum[@ID='JsPath']/text()[last()])"/>
    <xsl:variable name="CACHE_VERSION"  select="normalize-space(//Datum[@ID='CacheVersion']/text()[last()])"/>
    <xsl:variable name="HEADER_ALIGN_RAW" select="normalize-space(//Datum[@ID='HeaderAlignment']/text()[last()])"/>
    <xsl:variable name="HEADER_ALIGN">
      <xsl:choose>
        <xsl:when test="$HEADER_ALIGN_RAW = 'center'">center</xsl:when>
        <xsl:otherwise>left</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- Background video (shared IDs, with pre-cleanup Se* fallback) -->
    <xsl:variable name="SE_BG_ACCT">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'BgBrightcoveAccount'"/>
        <xsl:with-param name="legacy" select="'SeBgBrightcoveAccount'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BG_PLAYER">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'BgBrightcovePlayer'"/>
        <xsl:with-param name="legacy" select="'SeBgBrightcovePlayer'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BG_VIDEO_ID">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'BgBrightcoveVideoId'"/>
        <xsl:with-param name="legacy" select="'SeBgBrightcoveVideoId'"/>
      </xsl:call-template>
    </xsl:variable>
    <!-- Brightcove ID(s). A comma means one cut per breakpoint
         (mobile, tablet, desktop); the inline script below splits the
         list. Spaces around the commas are ignored. -->
    <xsl:variable name="SE_BG_IDS" select="translate($SE_BG_VIDEO_ID, ' ', '')"/>
    <!-- Brightcove in-page player script (same account + player as the
         old iframe URL) and the background-layer stylesheet that hides
         the player chrome. The stylesheet path falls back to the
         standard location when the Datum is missing (instances saved
         before it existed) or blank. -->
    <xsl:variable name="SE_BG_PLAYER_JS">https://players.brightcove.net/<xsl:value-of select="$SE_BG_ACCT"/>/<xsl:value-of select="$SE_BG_PLAYER"/>_default/index.min.js</xsl:variable>
    <xsl:variable name="SE_BG_LAYER_CSS_RAW" select="normalize-space(//Datum[@ID='BgBrightcoveLayerCssPath']/text()[last()])"/>
    <xsl:variable name="SE_BG_LAYER_CSS">
      <xsl:choose>
        <xsl:when test="$SE_BG_LAYER_CSS_RAW != ''"><xsl:value-of select="$SE_BG_LAYER_CSS_RAW"/></xsl:when>
        <xsl:otherwise>/assets/rbccm/css/components/rbccm-brightcove-bg-layer.css</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_BG_MP4">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'BgVideoMp4'"/>
        <xsl:with-param name="legacy" select="'SeBgVideoMp4'"/>
      </xsl:call-template>
    </xsl:variable>

    <!-- S+E-only Datums (IDs unchanged) -->
    <xsl:variable name="SE_INSIGHT_SOURCE_RAW" select="normalize-space(//Datum[@ID='SeInsightSource']/text()[last()])"/>
    <xsl:variable name="SE_INSIGHT_SOURCE">
      <xsl:choose>
        <xsl:when test="$SE_INSIGHT_SOURCE_RAW = 'manual'">manual</xsl:when>
        <xsl:when test="$SE_INSIGHT_SOURCE_RAW = 'auto-latest'">auto-latest</xsl:when>
        <xsl:otherwise>dcr-picker</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_FEED_URLS"    select="normalize-space(//Datum[@ID='SeInsightFeedUrls']/text()[last()])"/>
    <xsl:variable name="SE_TAG_KEYWORDS" select="normalize-space(//Datum[@ID='SeInsightTagKeywords']/text()[last()])"/>
    <xsl:variable name="SE_PINNED_URL"   select="normalize-space(//Datum[@ID='SeInsightPinnedUrl']/text()[last()])"/>
    <xsl:variable name="SE_LOCALE_RAW" select="normalize-space(//Datum[@ID='SeLocale']/text()[last()])"/>
    <xsl:variable name="SE_LOCALE">
      <xsl:choose>
        <xsl:when test="$SE_LOCALE_RAW = 'fr'">fr</xsl:when>
        <xsl:otherwise>en</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_AUTO_LINK_OVERRIDE" select="normalize-space(//Datum[@ID='SeInsightAutoLinkOverride']/text()[last()])"/>

    <!-- Lede: title line 1 + subtitle (shared IDs, pre-cleanup SeTitle* / SeBody* fallback) -->
    <xsl:variable name="SE_TITLE_TEXT">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'TitleLine1Text'"/>
        <xsl:with-param name="legacy" select="'SeTitleText'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_TITLE_TAG_RAW">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'TitleTag'"/>
        <xsl:with-param name="legacy" select="'SeTitleTag'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BODY_TEXT">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'SubtitleText'"/>
        <xsl:with-param name="legacy" select="'SeBodyText'"/>
        <xsl:with-param name="raw" select="true()"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BODY_TAG_RAW">
      <xsl:call-template name="datum">
        <xsl:with-param name="id" select="'SubtitleTag'"/>
        <xsl:with-param name="legacy" select="'SeBodyTag'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BODY_MAX_WIDTH"   select="normalize-space(//Datum[@ID='SeBodyMaxWidth']/text()[last()])"/>

    <xsl:variable name="SE_INS_EYE_TEXT"     select="normalize-space(//Datum[@ID='SeInsightEyebrowText']/text()[last()])"/>
    <!-- SeInsightEyebrowTag / BodyTag / DateTag were removed from the
         Properties (fixed p / p / span). Still read here so pages saved
         before the cleanup keep any custom value. -->
    <xsl:variable name="SE_INS_EYE_TAG_RAW"  select="normalize-space(//Datum[@ID='SeInsightEyebrowTag']/text()[last()])"/>
    <xsl:variable name="SE_INS_TITLE_TEXT"   select="normalize-space(//Datum[@ID='SeInsightTitleText']/text()[last()])"/>
    <xsl:variable name="SE_INS_BODY_TEXT"    select="//Datum[@ID='SeInsightBodyText']"/>
    <xsl:variable name="SE_INS_BODY_TAG_RAW" select="normalize-space(//Datum[@ID='SeInsightBodyTag']/text()[last()])"/>
    <xsl:variable name="SE_INS_DATE_TEXT"    select="normalize-space(//Datum[@ID='SeInsightDateText']/text()[last()])"/>
    <xsl:variable name="SE_INS_DATE_TAG_RAW" select="normalize-space(//Datum[@ID='SeInsightDateTag']/text()[last()])"/>

    <xsl:variable name="SE_INS_LINK_LABEL"   select="normalize-space(//Datum[@ID='SeInsightLinkLabel']/text()[last()])"/>
    <xsl:variable name="SE_INS_LINK_HREF"    select="normalize-space(//Datum[@ID='SeInsightLinkHref']/text()[last()])"/>
    <xsl:variable name="SE_INS_LINK_ARIA"    select="normalize-space(//Datum[@ID='SeInsightLinkAriaLabel']/text()[last()])"/>

    <!-- DCR-picker lookups. -->
    <xsl:variable name="SE_DCR_ROOT"         select="//Datum[@ID='SeInsightDcr']/DCR"/>
    <xsl:variable name="SE_DCR_TITLE"        select="normalize-space($SE_DCR_ROOT/*/title)"/>
    <xsl:variable name="SE_DCR_DESC"         select="$SE_DCR_ROOT/*/description"/>
    <xsl:variable name="SE_DCR_PUB"          select="normalize-space($SE_DCR_ROOT/*/publish_date)"/>
    <xsl:variable name="SE_DCR_LINK"         select="normalize-space($SE_DCR_ROOT/*/link)"/>
    <xsl:variable name="SE_DCR_URL"          select="normalize-space($SE_DCR_ROOT/*/url)"/>
    <xsl:variable name="SE_DCR_LINK_DATUM"   select="normalize-space(//Datum[@ID='SeInsightDcrLink']/text()[last()])"/>

    <!-- Character limits (see limitValue). -->
    <xsl:variable name="SE_TITLE_MAX">
      <xsl:call-template name="limitValue">
        <xsl:with-param name="raw" select="//Datum[@ID='SeInsightTitleLimit']/text()[last()]"/>
        <xsl:with-param name="default" select="70"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BODY_MAX">
      <xsl:call-template name="limitValue">
        <xsl:with-param name="raw" select="//Datum[@ID='SeInsightBodyLimit']/text()[last()]"/>
        <xsl:with-param name="default" select="170"/>
      </xsl:call-template>
    </xsl:variable>

    <!-- Effective card fields. -->
    <xsl:variable name="SE_EFF_TITLE">
      <xsl:choose>
        <xsl:when test="$SE_INSIGHT_SOURCE = 'dcr-picker' and $SE_INS_TITLE_TEXT = ''">
          <xsl:value-of select="$SE_DCR_TITLE"/>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="$SE_INS_TITLE_TEXT"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_EFF_BODY">
      <xsl:choose>
        <xsl:when test="$SE_INSIGHT_SOURCE = 'dcr-picker' and normalize-space($SE_INS_BODY_TEXT) = ''">
          <xsl:value-of select="$SE_DCR_DESC"/>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="$SE_INS_BODY_TEXT"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_EFF_DATE">
      <xsl:choose>
        <xsl:when test="$SE_INSIGHT_SOURCE = 'dcr-picker' and $SE_INS_DATE_TEXT = ''">
          <xsl:call-template name="formatPublishDate">
            <xsl:with-param name="raw" select="$SE_DCR_PUB"/>
          </xsl:call-template>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="$SE_INS_DATE_TEXT"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="SE_EFF_LINK_HREF">
      <xsl:choose>
        <xsl:when test="$SE_INSIGHT_SOURCE = 'dcr-picker'">
          <xsl:choose>
            <xsl:when test="$SE_DCR_LINK_DATUM != ''"><xsl:value-of select="$SE_DCR_LINK_DATUM"/></xsl:when>
            <xsl:when test="$SE_DCR_LINK != ''"><xsl:value-of select="$SE_DCR_LINK"/></xsl:when>
            <xsl:when test="$SE_DCR_URL != ''"><xsl:value-of select="$SE_DCR_URL"/></xsl:when>
            <xsl:otherwise><xsl:value-of select="$SE_INS_LINK_HREF"/></xsl:otherwise>
          </xsl:choose>
        </xsl:when>
        <xsl:otherwise><xsl:value-of select="$SE_INS_LINK_HREF"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <!-- Tag guards. -->
    <xsl:variable name="SE_TITLE_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$SE_TITLE_TAG_RAW"/>
        <xsl:with-param name="default" select="'h1'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_BODY_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$SE_BODY_TAG_RAW"/>
        <xsl:with-param name="default" select="'p'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_INS_EYE_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$SE_INS_EYE_TAG_RAW"/>
        <xsl:with-param name="default" select="'p'"/>
      </xsl:call-template>
    </xsl:variable>
    <!-- Insight card title is always an h2: it sits under the page h1
         with no other heading above it, so h3 would skip a level.
         Fixed on purpose; there is no tag picker for it. -->
    <xsl:variable name="SE_INS_TITLE_TAG">h2</xsl:variable>
    <xsl:variable name="SE_INS_BODY_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$SE_INS_BODY_TAG_RAW"/>
        <xsl:with-param name="default" select="'p'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="SE_INS_DATE_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$SE_INS_DATE_TAG_RAW"/>
        <xsl:with-param name="default" select="'span'"/>
      </xsl:call-template>
    </xsl:variable>

    <!-- Stylesheet hoist -->
    <xsl:if test="$CSS_PATH != ''">
      <link rel="stylesheet" type="text/css">
        <xsl:attribute name="href">
          <xsl:value-of select="$CSS_PATH"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </link>
    </xsl:if>
    <!-- Brightcove background only: the layer stylesheet, loaded before
         the player so its controls are hidden from the first frame. -->
    <xsl:if test="$SE_BG_MP4 = '' and $SE_BG_IDS != ''">
      <link rel="stylesheet" type="text/css">
        <xsl:attribute name="href">
          <xsl:value-of select="$SE_BG_LAYER_CSS"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </link>
    </xsl:if>

    <section>
      <xsl:attribute name="class">rbccm-hero rbccm-hero--strategy-and-economics<xsl:if test="$HEADER_ALIGN = 'center'"> rbccm-hero--header-center</xsl:if><xsl:if test="normalize-space(//Datum[@ID='HeroBreadcrumbs']) != ''"> rbccm-hero--has-breadcrumbs</xsl:if></xsl:attribute>
      <xsl:if test="$SECTION_ID != ''">
        <xsl:attribute name="id"><xsl:value-of select="$SECTION_ID"/></xsl:attribute>
      </xsl:if>
      <xsl:if test="$SECTION_ARIA != ''">
        <xsl:attribute name="aria-label"><xsl:value-of select="$SECTION_ARIA"/></xsl:attribute>
      </xsl:if>
      <xsl:attribute name="data-hero-source"><xsl:value-of select="$SE_INSIGHT_SOURCE"/></xsl:attribute>
      <!-- Limits for rbccm-hero.js when it fills the card from a feed. -->
      <xsl:attribute name="data-hero-title-max"><xsl:value-of select="$SE_TITLE_MAX"/></xsl:attribute>
      <xsl:attribute name="data-hero-body-max"><xsl:value-of select="$SE_BODY_MAX"/></xsl:attribute>
      <xsl:if test="$SE_INSIGHT_SOURCE = 'auto-latest'">
        <xsl:attribute name="data-hero-locale"><xsl:value-of select="$SE_LOCALE"/></xsl:attribute>
        <xsl:if test="$SE_TAG_KEYWORDS != ''">
          <xsl:attribute name="data-hero-tag-keywords"><xsl:value-of select="$SE_TAG_KEYWORDS"/></xsl:attribute>
        </xsl:if>
        <xsl:if test="$SE_AUTO_LINK_OVERRIDE != ''">
          <xsl:attribute name="data-hero-link-override"><xsl:value-of select="$SE_AUTO_LINK_OVERRIDE"/></xsl:attribute>
        </xsl:if>
      </xsl:if>
      <xsl:if test="$SE_INSIGHT_SOURCE = 'auto-latest' or $SE_INSIGHT_SOURCE = 'dcr-picker'">
        <xsl:if test="$SE_FEED_URLS != ''">
          <xsl:attribute name="data-hero-feed-urls"><xsl:value-of select="$SE_FEED_URLS"/></xsl:attribute>
        </xsl:if>
        <xsl:if test="$SE_PINNED_URL != ''">
          <xsl:attribute name="data-hero-pinned-url"><xsl:value-of select="$SE_PINNED_URL"/></xsl:attribute>
        </xsl:if>
      </xsl:if>

      <!-- Optional video backdrop. MP4 wins if both Datums are set;
           renders a native <video> for lighter payload + no player
           chrome. Falls back to a Brightcove iframe when only the
           Brightcove Video ID is populated. Blank both = solid fill. -->
      <xsl:choose>
        <xsl:when test="$SE_BG_MP4 != ''">
          <div class="rbccm-hero__bg-video" aria-hidden="true">
            <video autoplay="autoplay" muted="muted" loop="loop" playsinline="playsinline" preload="auto">
              <source type="video/mp4">
                <xsl:attribute name="src"><xsl:value-of select="$SE_BG_MP4"/></xsl:attribute>
              </source>
            </video>
          </div>
        </xsl:when>
        <!-- Brightcove, in-page embed (not an iframe) so the page can
             style the player: rbccm-brightcove-bg-layer.css hides every
             control from the first frame and crops the video to cover
             the hero. One ID plays at every width; IDs separated by
             commas are one cut per breakpoint:
               3 IDs  mobile (under 768), tablet (768-991), desktop (992+)
               2 IDs  mobile, desktop (tablet uses desktop)
             The inline script picks the cut for the current width before
             the player loads, loads Brightcove's player script once, and
             swaps the cut if the width crosses a breakpoint. inert keeps
             the player out of the tab order and the accessibility tree. -->
        <xsl:when test="$SE_BG_IDS != ''">
          <div class="rbccm-hero__bg-video rbccm-brightcove-bg-layer" aria-hidden="true" inert="inert">
            <xsl:attribute name="data-bg-video-ids"><xsl:value-of select="$SE_BG_IDS"/></xsl:attribute>
            <xsl:attribute name="data-bg-player-js"><xsl:value-of select="$SE_BG_PLAYER_JS"/></xsl:attribute>
            <video-js class="rbccm-brightcove-bg-layer__player" data-embed="default" muted="muted" autoplay="autoplay" loop="loop" playsinline="playsinline" preload="auto" tabindex="-1">
              <xsl:attribute name="data-account"><xsl:value-of select="$SE_BG_ACCT"/></xsl:attribute>
              <xsl:attribute name="data-player"><xsl:value-of select="$SE_BG_PLAYER"/></xsl:attribute>
            </video-js>
          </div>
          <script>
(function () {
  var s = document.currentScript;
  var wrap = s ? s.previousElementSibling : null;
  var el = wrap ? wrap.querySelector('video-js') : null;
  if (!el) return;
  var ids = (wrap.getAttribute('data-bg-video-ids') || '').split(',').filter(function (id) { return id; });
  if (!ids.length) return;
  var byWidth = {
    mobile:  ids[0],
    tablet:  ids.length > 2 ? ids[1] : ids[ids.length - 1],
    desktop: ids[ids.length > 2 ? 2 : ids.length - 1]
  };
  var desktop = window.matchMedia ? window.matchMedia('(min-width: 992px)') : null;
  var tablet = window.matchMedia ? window.matchMedia('(min-width: 768px)') : null;
  function currentId() {
    if (!desktop) return byWidth.desktop;
    return byWidth[desktop.matches ? 'desktop' : (tablet.matches ? 'tablet' : 'mobile')];
  }
  if (!el.id) el.id = 'rbccm-bg-player-' + Math.random().toString(36).slice(2, 9);
  el.setAttribute('data-video-id', currentId());

  function getPlayer() {
    return window.videojs ? window.videojs.getPlayer(el.id) : null;
  }
  function quiet(player) {
    player.controls(false);
    player.muted(true);
    var p = player.play();
    if (p) {
      if (p.catch) p.catch(function () {});
    }
  }
  function onReady() {
    var player = getPlayer();
    if (!player) return;
    player.ready(function () { quiet(player); });
    if (!desktop) return;
    var shown = currentId();
    function swap() {
      var id = currentId();
      if (id === shown) return;
      shown = id;
      if (!player.catalog) return;
      player.catalog.getVideo(id, function (err, video) {
        if (err) return;
        player.catalog.load(video);
        quiet(player);
      });
    }
    [desktop, tablet].forEach(function (q) {
      if (q.addEventListener) q.addEventListener('change', swap);
      else if (q.addListener) q.addListener(swap);
    });
  }

  /* Brightcove's script sets up every video-js tag on the page when it
     loads. If another component already loaded it, set this one up
     with bc(); otherwise add the script once. */
  var src = wrap.getAttribute('data-bg-player-js');
  var existing = document.querySelector('script[src="' + src + '"]');
  if (window.bc) {
    if (existing) {
      window.bc(el);
      onReady();
      return;
    }
  }
  var tag = existing || document.createElement('script');
  tag.addEventListener('load', onReady);
  if (!existing) {
    tag.src = src;
    document.body.appendChild(tag);
  }
})();
          </script>
        </xsl:when>
      </xsl:choose>

      <!-- Decorative blur ellipse (desktop only, per CSS). -->
      <div class="rbccm-hero__blur" aria-hidden="true"></div>

      <!-- Breadcrumbs: first content in the section, above the container
           (copy + card row). -->
      <xsl:call-template name="heroBreadcrumbs"/>

      <div class="rbccm-hero__container">
        <div class="rbccm-hero__grid">

          <!-- Left column: title + body -->
          <div class="rbccm-hero__lede">

            <xsl:if test="$SE_TITLE_TEXT != ''">
              <xsl:element name="{$SE_TITLE_TAG}">
                <xsl:attribute name="class">rbccm-hero__title</xsl:attribute>
                <xsl:attribute name="data-hero-rise">rise</xsl:attribute>
                <xsl:value-of select="$SE_TITLE_TEXT"/>
              </xsl:element>
            </xsl:if>

            <xsl:if test="normalize-space($SE_BODY_TEXT) != ''">
              <xsl:element name="{$SE_BODY_TAG}">
                <xsl:attribute name="class">rbccm-hero__body</xsl:attribute>
                <xsl:attribute name="data-hero-rise">rise</xsl:attribute>
                <xsl:attribute name="data-animate-delay">150</xsl:attribute>
                <!-- Optional desktop max-width for widow control. When the
                     SeBodyMaxWidth Datum is non-blank, its value is passed
                     through as a CSS custom property that the desktop rule
                     in rbccm-hero.css picks up (blank == default 100%). -->
                <xsl:if test="$SE_BODY_MAX_WIDTH != ''">
                  <xsl:attribute name="style">--rbccm-hero-se-body-max-width: <xsl:value-of select="$SE_BODY_MAX_WIDTH"/>;</xsl:attribute>
                </xsl:if>
                <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$SE_BODY_TEXT"/></xsl:call-template>
              </xsl:element>
            </xsl:if>

          </div>

          <!-- Right column: dark-navy insight card -->
          <article class="rbccm-hero__insight-card" data-hero-rise="rise" data-animate-delay="325">

            <xsl:if test="$SE_INS_EYE_TEXT != ''">
              <div class="rbccm-hero__insight-eyebrow-row">
                <div class="rbccm-hero__insight-eyebrow-inner">
                  <xsl:element name="{$SE_INS_EYE_TAG}">
                    <xsl:attribute name="class">rbccm-hero__insight-eyebrow</xsl:attribute>
                    <xsl:value-of select="$SE_INS_EYE_TEXT"/>
                  </xsl:element>
                </div>
              </div>
            </xsl:if>

            <xsl:if test="$SE_EFF_TITLE != ''">
              <xsl:element name="{$SE_INS_TITLE_TAG}">
                <xsl:attribute name="class">rbccm-hero__insight-title</xsl:attribute>
                <xsl:call-template name="truncate">
                  <xsl:with-param name="text" select="$SE_EFF_TITLE"/>
                  <xsl:with-param name="max" select="number($SE_TITLE_MAX)"/>
                </xsl:call-template>
              </xsl:element>
            </xsl:if>

            <xsl:if test="normalize-space($SE_EFF_BODY) != ''">
              <xsl:element name="{$SE_INS_BODY_TAG}">
                <xsl:attribute name="class">rbccm-hero__insight-body</xsl:attribute>
                <!-- Within the limit: output as authored (HTML kept).
                     Over it: plain text cut to the limit. -->
                <xsl:variable name="bodyPlain">
                  <xsl:call-template name="stripTags"><xsl:with-param name="s" select="$SE_EFF_BODY"/></xsl:call-template>
                </xsl:variable>
                <xsl:choose>
                  <xsl:when test="number($SE_BODY_MAX) &lt;= 0 or string-length(normalize-space($bodyPlain)) &lt;= number($SE_BODY_MAX)">
                    <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$SE_EFF_BODY"/></xsl:call-template>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:call-template name="truncate">
                      <xsl:with-param name="text" select="$bodyPlain"/>
                      <xsl:with-param name="max" select="number($SE_BODY_MAX)"/>
                    </xsl:call-template>
                  </xsl:otherwise>
                </xsl:choose>
              </xsl:element>
            </xsl:if>

            <xsl:if test="$SE_EFF_DATE != '' or $SE_INS_LINK_LABEL != ''">
              <footer class="rbccm-hero__insight-footer">

                <xsl:if test="$SE_EFF_DATE != ''">
                  <xsl:element name="{$SE_INS_DATE_TAG}">
                    <xsl:attribute name="class">rbccm-hero__insight-date</xsl:attribute>
                    <xsl:value-of select="$SE_EFF_DATE"/>
                  </xsl:element>
                </xsl:if>

                <xsl:if test="$SE_INS_LINK_LABEL != ''">
                  <a class="rbccm-hero__insight-link">
                    <xsl:attribute name="href"><xsl:value-of select="$SE_EFF_LINK_HREF"/></xsl:attribute>
                    <!-- aria-label ALWAYS emitted so "Read more" is meaningful to
                         screen readers. Prefer the explicit Datum override; fall
                         back to composing "{label}: {title}" so bare "Read more"
                         still announces which insight it targets. -->
                    <xsl:attribute name="aria-label">
                      <xsl:choose>
                        <xsl:when test="$SE_INS_LINK_ARIA != ''"><xsl:value-of select="$SE_INS_LINK_ARIA"/></xsl:when>
                        <xsl:when test="$SE_EFF_TITLE != ''"><xsl:value-of select="$SE_INS_LINK_LABEL"/>: <xsl:value-of select="$SE_EFF_TITLE"/></xsl:when>
                        <xsl:otherwise><xsl:value-of select="$SE_INS_LINK_LABEL"/></xsl:otherwise>
                      </xsl:choose>
                    </xsl:attribute>
                    <xsl:value-of select="$SE_INS_LINK_LABEL"/>
                    <svg class="rbccm-hero__insight-link-icon" xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                      <path d="M2.70801 6.5H10.2913" stroke="#FFC72C" stroke-width="1.08333" stroke-linecap="round" stroke-linejoin="round"/>
                      <path d="M6.5 2.70825L10.2917 6.49992L6.5 10.2916" stroke="#FFC72C" stroke-width="1.08333" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </a>
                </xsl:if>

              </footer>
            </xsl:if>

          </article>

        </div>
      </div>
    </section>

    <!-- Hydrator script (only when auto-latest or dcr-picker w/ pinned URL). -->
    <xsl:if test="$JS_PATH != '' and ($SE_INSIGHT_SOURCE = 'auto-latest' or ($SE_INSIGHT_SOURCE = 'dcr-picker' and $SE_PINNED_URL != ''))">
      <script>
        <xsl:attribute name="src">
          <xsl:value-of select="$JS_PATH"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </script>
    </xsl:if>

  </xsl:template>

</xsl:stylesheet>
