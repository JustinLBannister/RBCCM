<?xml version="1.0" encoding="UTF-8"?>
<!--
  RBCCM Expertise :: strategy-and-economics-expertise (single-skin build)
  ==============================================================
  Standalone XSL skin for TeamSite's Skin dropdown. Renders ONLY
  the "Strategy and Economics" preset of rbccm-expertise. No
  Preset branching - the variant class is hardcoded below.

  Structure: header (title + description) -> 4-pillar track ->
  arrow controls + dot pager. Each pillar reveals with a
  0/150/300/450ms fadeInUp cascade.

  Companion skin: rbccm-expertise-why-rbc-capital-markets.xsl
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:output method="html" indent="no" omit-xml-declaration="yes"/>

  <!-- Tag allow-list guard. -->
  <!-- Rich text output. Text pasted into the editor straight from Figma
       carries two hidden spans (data-metadata="(figmeta)..." and
       data-buffer="(figma)...") holding the Figma file key and a base64
       copy of the design, often tens of KB per field. They are invisible
       but bloat the page and expose internal file details, so they are
       removed here; all other HTML is output as entered. -->
  <xsl:template name="rbccmRich">
    <xsl:param name="s"/>
    <xsl:variable name="clean"><xsl:call-template name="rbccmStripFigma"><xsl:with-param name="s" select="string($s)"/></xsl:call-template></xsl:variable>
    <xsl:value-of select="$clean" disable-output-escaping="yes"/>
  </xsl:template>

  <xsl:template name="rbccmStripFigma">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, '&lt;span data-metadata=') and contains(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-metadata='), substring-after(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="contains($s, '&lt;span data-buffer=') and contains(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-buffer='), substring-after(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="pickTag">
    <xsl:param name="raw"/>
    <xsl:param name="default"/>
    <xsl:choose>
      <xsl:when test="$raw = 'h1' or $raw = 'h2' or $raw = 'h3' or $raw = 'h4' or $raw = 'h5' or $raw = 'h6' or $raw = 'p' or $raw = 'div' or $raw = 'span'">
        <xsl:value-of select="$raw"/>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$default"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Icon library. Extend by adding another xsl:when here. -->
  <xsl:template name="iconSvg">
    <xsl:param name="name"/>
    <xsl:choose>
      <xsl:when test="$name = 'globe'">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" fill="none" aria-hidden="true">
          <path d="M30 15C30 11.0218 28.4196 7.20644 25.6066 4.3934C22.7936 1.58035 18.9782 0 15 0C11.0218 0 7.20644 1.58035 4.3934 4.3934C1.58035 7.20644 0 11.0218 0 15C0 18.9782 1.58035 22.7936 4.3934 25.6066C7.20644 28.4196 11.0218 30 15 30C18.9782 30 22.7936 28.4196 25.6066 25.6066C28.4196 22.7936 30 18.9782 30 15ZM15.9375 2.01938C17.1938 2.40188 18.4406 3.55687 19.4756 5.4975C19.7444 6.00125 19.9913 6.54625 20.2163 7.1325C18.8944 7.42687 17.4563 7.61438 15.9375 7.67063V2.01938ZM22.0331 6.63562C21.7656 5.91437 21.465 5.24062 21.1313 4.61438C20.8049 4.0026 20.4306 3.41764 20.0119 2.865C21.6084 3.52606 23.0586 4.49586 24.2794 5.71875C23.5994 6.065 22.8506 6.36937 22.0331 6.63562ZM23.4206 14.0625C23.3531 12.0562 23.0681 10.1494 22.6031 8.4225C23.6185 8.09921 24.6011 7.68047 25.5375 7.17188C27.0312 9.17671 27.9176 11.5684 28.0912 14.0625H23.4206ZM20.7956 8.92312C21.2383 10.6025 21.4899 12.3266 21.5456 14.0625H15.9375V9.54562C17.6438 9.48938 19.2806 9.27375 20.7956 8.92312ZM14.0625 9.54375V14.0625H8.45625C8.51132 12.3267 8.76229 10.6026 9.20438 8.92312C10.7194 9.27375 12.3563 9.48563 14.0625 9.54375ZM21.5437 15.9375C21.4781 17.7881 21.2137 19.5263 20.7956 21.0769C19.1999 20.7146 17.573 20.5068 15.9375 20.4562V15.9375H21.5437ZM14.0625 15.9375V20.4544C12.3563 20.5106 10.7194 20.7263 9.20438 21.0769C8.78625 19.5263 8.52187 17.7881 8.45437 15.9375H14.0625ZM20.2163 22.8675C19.9913 23.4538 19.7444 23.9988 19.4756 24.5025C18.4406 26.4431 17.1919 27.5963 15.9375 27.9806V22.3312C17.4563 22.3875 18.8944 22.5731 20.2163 22.8675ZM20.01 27.135C20.4294 26.5824 20.8043 25.9975 21.1313 25.3856C21.4759 24.7317 21.7771 24.0559 22.0331 23.3625C22.8044 23.6105 23.5554 23.9177 24.2794 24.2812C23.0586 25.5041 21.6065 26.4739 20.01 27.135ZM22.6031 21.5775C23.0893 19.7347 23.3642 17.8425 23.4225 15.9375H28.0912C27.9176 18.4316 27.0312 20.8233 25.5375 22.8281C24.6562 22.3444 23.6719 21.9244 22.6031 21.5775ZM9.98812 27.135C8.39247 26.4743 6.9429 25.5051 5.7225 24.2831C6.4459 23.9196 7.19625 23.6125 7.96688 23.3644C8.22294 24.0571 8.52422 24.7323 8.86875 25.3856C9.19508 25.9974 9.56938 26.5824 9.98812 27.135ZM14.0625 22.3294V27.9806C12.8062 27.5981 11.5594 26.4431 10.5244 24.5025C10.2544 23.9988 10.0075 23.4538 9.78375 22.8675C11.1907 22.5587 12.6229 22.3773 14.0625 22.3294ZM7.39687 21.5775C6.32812 21.9244 5.34375 22.3444 4.4625 22.8281C2.96877 20.8233 2.08237 18.4316 1.90875 15.9375H6.5775C6.63583 17.8425 6.91072 19.7347 7.39687 21.5775ZM1.90875 14.0625C2.08237 11.5684 2.96877 9.17671 4.4625 7.17188C5.34375 7.65562 6.32812 8.07563 7.39687 8.4225C6.93187 10.1475 6.64688 12.0562 6.5775 14.0625H1.90875ZM8.86875 4.61438C8.53625 5.24188 8.235 5.91562 7.965 6.63562C7.19501 6.38742 6.4453 6.08026 5.7225 5.71688C6.94306 4.49554 8.39262 3.52704 9.98812 2.86688C9.57937 3.3975 9.20437 3.98625 8.86875 4.61438ZM9.78375 7.1325C9.99777 6.5732 10.2451 6.02723 10.5244 5.4975C11.5594 3.55687 12.8062 2.40375 14.0625 2.01938V7.66875C12.5438 7.6125 11.1056 7.42687 9.78375 7.1325Z" fill="currentColor"/>
        </svg>
      </xsl:when>
      <xsl:when test="$name = 'bank'">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" fill="none" aria-hidden="true">
          <path d="M15 0L2.60652 5.625H0.937811C0.689175 5.625 0.450724 5.72377 0.274912 5.89959C0.0991001 6.0754 0.000333786 6.31386 0.000333786 6.5625V10.3125C0.000333786 10.5611 0.0991001 10.7996 0.274912 10.9754C0.450724 11.1512 0.689175 11.25 0.937811 11.25H1.87529V24.375C1.66592 24.3752 1.46264 24.4454 1.29783 24.5745C1.13302 24.7037 1.01618 24.8842 0.965935 25.0875L0.0284557 28.8375C-0.00644112 28.9756 -0.00927925 29.1199 0.0201569 29.2592C0.0495949 29.3986 0.110525 29.5294 0.198288 29.6416C0.286051 29.7538 0.398319 29.8444 0.526499 29.9065C0.654678 29.9686 0.795372 30.0006 0.937811 30H29.0622C29.2046 30.0006 29.3453 29.9686 29.4735 29.9065C29.6017 29.8444 29.7139 29.7538 29.8017 29.6416C29.8895 29.5294 29.9504 29.3986 29.9798 29.2592C30.0093 29.1199 30.0064 28.9756 29.9715 28.8375L29.0341 25.0875C28.9838 24.8842 28.867 24.7037 28.7022 24.5745C28.5374 24.4454 28.3341 24.3752 28.1247 24.375V11.25H29.0622C29.3108 11.25 29.5493 11.1512 29.7251 10.9754C29.9009 10.7996 29.9997 10.5611 29.9997 10.3125V6.5625C29.9997 6.31386 29.9009 6.0754 29.7251 5.89959C29.5493 5.72377 29.3108 5.625 29.0622 5.625H27.3935L15 0ZM22.918 5.625H7.08018L15 1.875L22.918 5.625ZM26.2498 11.25V24.375H24.3748V11.25H26.2498ZM22.4998 11.25V24.375H17.8124V11.25H22.4998ZM15.9375 11.25V24.375H14.0625V11.25H15.9375ZM12.1876 11.25V24.375H7.50017V11.25H12.1876ZM5.62521 11.25V24.375H3.75025V11.25H5.62521ZM1.87529 9.375V7.5H28.1247V9.375H1.87529ZM2.60652 26.25H27.3935L27.8622 28.125H2.13778L2.60652 26.25Z" fill="currentColor"/>
        </svg>
      </xsl:when>
      <xsl:when test="$name = 'chart'">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 30" fill="none" fill-rule="evenodd" aria-hidden="true">
          <g clip-path="url(#clip0_rbccm_expertise_chart_sae)" fill-rule="evenodd">
            <path d="M31.9491 0.200487C31.832 0.09921 31.5412 0 31.358 0L29.2814 0.0199798C29.0934 0.0220467 28.9197 0.0978321 28.7923 0.233557C28.6621 0.372038 28.5939 0.558745 28.6035 0.746142C28.6228 1.10371 28.9066 1.37378 29.278 1.38894L29.7844 1.40961L26.5532 4.56917C23.2324 7.81692 19.2378 10.3047 14.6803 11.9651C10.395 13.5263 5.73285 14.3179 0.823331 14.3179H0.756502C0.523634 14.3179 0.318324 14.3985 0.179844 14.5446C0.0544532 14.6769 -0.00893092 14.856 0.0007145 15.0489C0.0206943 15.4368 0.325214 15.6972 0.758569 15.6972C5.85066 15.6938 10.6747 14.8801 15.0965 13.279C19.8131 11.5711 23.9572 9.00262 27.4137 5.64395L30.7875 2.36588L30.8054 2.91705C30.8178 3.30218 31.112 3.59292 31.4895 3.59292C31.5026 3.59292 31.5157 3.59292 31.5281 3.59154C31.8354 3.57569 32.1689 3.31251 32.1737 2.91498L32.1978 0.841218C32.1999 0.646932 32.0917 0.324499 31.9477 0.200487H31.9491ZM32.0373 2.9136C32.0338 3.22088 31.7762 3.44135 31.5219 3.45444C31.2105 3.47097 30.9549 3.24706 30.9439 2.91292L30.9156 2.05103L27.3186 5.54611C20.1837 12.4791 10.5914 15.5532 0.759257 15.5601C0.398243 15.5601 0.154352 15.3569 0.138506 15.042C0.120593 14.7024 0.374819 14.4557 0.75788 14.4564C10.331 14.4702 19.7263 11.4381 26.6496 4.66838L30.1089 1.2856L29.2835 1.25184C28.97 1.23875 28.7565 1.0169 28.7413 0.739252C28.7255 0.449201 28.948 0.161905 29.2828 0.15846L31.3593 0.138481C31.5026 0.137103 31.7644 0.223911 31.8588 0.305209C31.9636 0.396151 32.0628 0.672423 32.0614 0.840529L32.0373 2.91429V2.9136Z" fill="currentColor"/>
            <path d="M31.8596 0.305192C31.7652 0.223206 31.5034 0.136397 31.3601 0.138464L29.2836 0.158444C28.9494 0.161889 28.7269 0.449184 28.7421 0.739235C28.7572 1.01757 28.9708 1.23942 29.2843 1.25182L30.1096 1.28558L26.6504 4.66836C19.727 11.4374 10.3317 14.4702 0.757958 14.4564C0.374898 14.4564 0.120672 14.703 0.138585 15.042C0.15512 15.3562 0.398322 15.5601 0.759336 15.5601C10.5915 15.5532 20.1838 12.4791 27.3187 5.5461L30.9157 2.05101L30.944 2.9129C30.955 3.24704 31.2106 3.47095 31.522 3.45442C31.7755 3.44133 32.0332 3.22086 32.0374 2.91359L32.0615 0.839823C32.0635 0.671718 31.9643 0.395445 31.8589 0.304503L31.8596 0.305192Z" fill="currentColor"/>
            <path d="M30.9363 19.2778C30.9232 19.2778 30.9108 19.2778 30.8977 19.2792C30.5835 19.2971 30.2501 19.5437 30.2501 19.9661L30.2487 27.6548C30.2487 27.8822 30.0606 28.0737 29.8381 28.0737H28.7371C28.5063 28.073 28.3251 27.8863 28.3251 27.648V11.175C28.3251 10.9373 28.5063 10.7506 28.7371 10.7499L29.8388 10.7485C30.0606 10.7485 30.2487 10.9386 30.2487 11.1632L30.2521 15.0118C30.2521 15.4389 30.6028 15.6945 30.9411 15.6945C30.9535 15.6945 30.9659 15.6945 30.9783 15.6938C31.2897 15.6773 31.6259 15.4114 31.6252 15.0125V11.1577C31.6238 10.1746 30.826 9.37402 29.8443 9.37402L28.7309 9.3754C27.7319 9.37609 26.95 10.1636 26.95 11.1681V27.6555C26.95 28.66 27.7326 29.4475 28.7316 29.4482H29.8463C30.8274 29.4482 31.6252 28.6469 31.6252 27.661V19.9654C31.6252 19.5355 31.2759 19.2778 30.937 19.2778H30.9363ZM31.4867 27.661C31.4867 28.5856 30.7468 29.3118 29.8443 29.3111H28.7309C27.8256 29.3097 27.0871 28.5891 27.0871 27.6555V11.1681C27.0871 10.2352 27.8256 9.51388 28.7302 9.51319L29.8436 9.51182C30.7482 9.51113 31.4854 10.2435 31.4854 11.1577V15.0125C31.4867 15.3259 31.2242 15.543 30.9693 15.5567C30.6751 15.5726 30.3885 15.3507 30.3885 15.0125L30.3851 11.1639C30.3851 10.8622 30.1343 10.6107 29.8367 10.6114L28.7357 10.6128C28.4388 10.6128 28.1859 10.8505 28.1859 11.1756V27.6486C28.1859 27.9725 28.4381 28.2108 28.7357 28.2108H29.8367C30.1322 28.2122 30.3858 27.9649 30.3858 27.6548L30.3872 19.9661C30.3872 19.6402 30.6441 19.4314 30.9046 19.417C31.1932 19.4004 31.4861 19.6181 31.4861 19.9654V27.661H31.4867Z" fill="currentColor"/>
            <path d="M30.9054 19.4169C30.6442 19.4321 30.388 19.6409 30.388 19.966L30.3866 27.6548C30.3866 27.9649 30.1337 28.2115 29.8375 28.2115H28.7365C28.4396 28.2101 28.1867 27.9724 28.1867 27.6479V11.1749C28.1867 10.8498 28.4389 10.6128 28.7365 10.6121L29.8375 10.6107C30.1351 10.6107 30.3852 10.8615 30.3859 11.1632L30.3893 15.0118C30.3893 15.35 30.6766 15.5719 30.9701 15.556C31.225 15.5422 31.4868 15.3252 31.4868 15.0118V11.157C31.4855 10.2428 30.7483 9.51042 29.8437 9.51111L28.7303 9.51249C27.8257 9.51318 27.0872 10.2345 27.0872 11.1674V27.6548C27.0872 28.5884 27.8257 29.309 28.731 29.3097H29.8444C30.7469 29.3111 31.4862 28.5849 31.4868 27.6603V19.9647C31.4868 19.6174 31.1947 19.3997 30.9061 19.4163L30.9054 19.4169Z" fill="currentColor"/>
            <path d="M23.2366 14.4626H22.135C21.8381 14.4626 21.5852 14.703 21.5852 15.0234V28.1997C21.5852 28.5229 21.8381 28.7578 22.135 28.7592L23.2704 28.7661C23.5653 28.7116 23.7857 28.5112 23.7857 28.1991V15.0234C23.7857 14.7024 23.5322 14.4619 23.2366 14.4619V14.4626ZM23.258 28.629L22.1364 28.6221C21.9049 28.6207 21.7237 28.4354 21.7237 28.2004V15.0241C21.7237 14.7864 21.9042 14.6011 22.135 14.6011H23.2366C23.4674 14.6011 23.6479 14.7871 23.6479 15.0248V28.2004C23.6479 28.4209 23.5026 28.5807 23.2573 28.6297L23.258 28.629Z" fill="currentColor"/>
            <path d="M23.2427 13.2252H22.1293C21.1304 13.2252 20.3484 14.012 20.3484 15.0165V28.2073C20.3484 29.2125 21.1276 29.9993 22.1218 29.9993L23.2868 29.9938C24.2451 29.989 25.0243 29.1877 25.0243 28.2073V15.0172C25.0243 14.0127 24.2424 13.2259 23.2434 13.2259L23.2427 13.2252ZM24.8859 28.2073C24.8859 29.105 24.1907 29.8512 23.2854 29.856L22.13 29.8615C21.2247 29.8663 20.4862 29.1402 20.4862 28.2073V15.0165C20.4862 14.0857 21.2254 13.363 22.1293 13.363H23.2427C24.1466 13.363 24.8859 14.0844 24.8859 15.0165V28.2066V28.2073Z" fill="currentColor"/>
            <path d="M23.2428 13.363H22.1295C21.2256 13.363 20.4863 14.0858 20.4863 15.0165V28.2073C20.4863 29.1402 21.2249 29.8663 22.1302 29.8615L23.2856 29.856C24.1909 29.8512 24.886 29.105 24.886 28.2073V15.0172C24.886 14.0851 24.1468 13.3637 23.2428 13.3637V13.363ZM23.2711 28.7668L22.1357 28.7599C21.8388 28.7578 21.5859 28.5236 21.5859 28.2004V15.0241C21.5859 14.7031 21.8381 14.4633 22.1357 14.4633H23.2373C23.5336 14.4633 23.7864 14.7037 23.7864 15.0248V28.2004C23.7864 28.5125 23.566 28.7137 23.2711 28.7675V28.7668Z" fill="currentColor"/>
            <path d="M16.6356 17.7627H15.534C15.237 17.7627 14.9849 18.0059 14.9849 18.3214V28.2025C14.9849 28.5201 15.2377 28.7578 15.5347 28.7598L16.6701 28.766C16.9642 28.7144 17.1854 28.507 17.1854 28.2018V18.3214C17.1854 18.0052 16.9319 17.7627 16.6363 17.7627H16.6356ZM16.6577 28.6289L15.5353 28.6227C15.3039 28.6214 15.1227 28.4374 15.1227 28.2032V18.3221C15.1227 18.09 15.3073 17.9012 15.534 17.9012H16.6356C16.7438 17.9012 16.8457 17.9439 16.9236 18.0217C17.0028 18.101 17.0469 18.2078 17.0469 18.3221V28.2025C17.0469 28.4608 16.8478 28.5917 16.6577 28.6289Z" fill="currentColor"/>
            <path d="M16.6418 16.5261H15.5278C14.546 16.5261 13.7468 17.3287 13.7468 18.3153V28.2101C13.7468 29.1967 14.5419 30 15.5195 30L16.6845 29.9945C17.6422 29.9897 18.4221 29.1891 18.4221 28.2108V18.316C18.4221 17.8323 18.2368 17.3811 17.8992 17.0448C17.5643 16.7107 17.1172 16.5268 16.6418 16.5268V16.5261ZM18.285 28.2094C18.285 29.1023 17.5898 29.8512 16.6845 29.8553L15.5285 29.8609C14.6239 29.8657 13.8853 29.1374 13.8853 28.2087V18.3139C13.8853 17.3879 14.6246 16.6625 15.5285 16.6625H16.6425C17.5464 16.6625 18.2857 17.3866 18.2857 18.3139V28.2087L18.285 28.2094Z" fill="currentColor"/>
            <path d="M16.642 16.6638H15.5279C14.624 16.6638 13.8848 17.3886 13.8848 18.3153V28.2101C13.8848 29.1388 14.624 29.8663 15.5286 29.8622L16.6847 29.8567C17.5893 29.8519 18.2851 29.103 18.2851 28.2108V18.3159C18.2851 17.3886 17.5459 16.6645 16.6427 16.6645L16.642 16.6638ZM16.6702 28.7667L15.5348 28.7605C15.2379 28.7592 14.985 28.5215 14.985 28.2032V18.3221C14.985 18.0066 15.2379 17.7634 15.5341 17.7634H16.6358C16.9313 17.7634 17.1849 18.0059 17.1849 18.3221V28.2025C17.1849 28.5084 16.9644 28.7151 16.6695 28.7667H16.6702Z" fill="currentColor"/>
            <path d="M10.0348 21.0635H8.93313C8.63619 21.0635 8.38403 21.3101 8.38403 21.6188V28.2066C8.38403 28.5173 8.63688 28.7592 8.93313 28.7605L10.0692 28.766C10.3627 28.7171 10.5839 28.5022 10.5839 28.2052V21.6181C10.5839 21.3088 10.3303 21.0628 10.0348 21.0628V21.0635ZM10.0575 28.6283L8.93382 28.6227C8.70647 28.6214 8.52182 28.4347 8.52182 28.2066V21.6188C8.52182 21.3928 8.7106 21.2013 8.93313 21.2013H10.0348C10.258 21.2013 10.4461 21.3928 10.4461 21.6188V28.2059C10.4461 28.4202 10.2938 28.5849 10.0575 28.6289V28.6283Z" fill="currentColor"/>
            <path d="M10.041 19.8262H8.927C8.45162 19.8262 8.00517 20.0108 7.66965 20.3456C7.33206 20.6825 7.14673 21.1317 7.14673 21.612V28.2129C7.14673 29.1981 7.94179 29.9993 8.91942 29.9993L10.0844 29.9938C11.0421 29.989 11.8213 29.1905 11.8213 28.2136V21.6126C11.8213 20.6281 11.0228 19.8269 10.041 19.8269V19.8262ZM11.6835 28.2136C11.6835 29.0982 10.9884 29.8519 10.0838 29.856L8.92769 29.8615C8.02308 29.8664 7.28452 29.134 7.28452 28.2129V21.612C7.28452 20.6936 8.02377 19.964 8.927 19.964H10.041C10.9443 19.964 11.6835 20.6922 11.6835 21.612V28.2129V28.2136Z" fill="currentColor"/>
            <path d="M10.0409 19.9639H8.9269C8.02368 19.9639 7.28442 20.6928 7.28442 21.6119V28.2128C7.28442 29.134 8.02299 29.8656 8.92759 29.8615L10.0837 29.856C10.9883 29.8512 11.6834 29.0974 11.6834 28.2135V21.6126C11.6834 20.6928 10.9449 19.9646 10.0409 19.9646V19.9639ZM10.0692 28.7661L8.9331 28.7605C8.63685 28.7592 8.384 28.5173 8.384 28.2066V21.6188C8.384 21.3102 8.63685 21.0635 8.9331 21.0635H10.0347C10.3303 21.0635 10.5838 21.3102 10.5838 21.6188V28.2059C10.5838 28.5022 10.3627 28.7178 10.0692 28.7667V28.7661Z" fill="currentColor"/>
            <path d="M3.43997 23.1263H2.32592C1.34416 23.1263 0.545654 23.9255 0.545654 24.9079V28.217C0.545654 29.2001 1.34071 29.9993 2.31834 29.9993L3.48337 29.9938C4.44102 29.989 5.21955 29.1926 5.22024 28.2177V24.9086C5.22024 24.4319 5.03491 23.9847 4.69801 23.6478C4.36179 23.3116 3.91535 23.127 3.44066 23.127L3.43997 23.1263ZM5.08176 28.2177C5.08176 29.0913 4.38729 29.8519 3.48268 29.856L2.32661 29.8615C1.42201 29.8664 0.684135 29.1285 0.684135 28.217V24.9079C0.684135 23.9992 1.4227 23.2641 2.32592 23.2641H3.43997C4.34388 23.2641 5.08176 23.9978 5.08176 24.9079V28.217V28.2177Z" fill="currentColor"/>
            <path d="M3.43395 24.3636H2.3323C2.03605 24.3636 1.7832 24.6144 1.7832 24.9148V28.2107C1.7832 28.5132 2.03605 28.7598 2.3323 28.7605L3.4684 28.7654C3.76051 28.7199 3.98305 28.496 3.98305 28.2094V24.9141C3.98305 24.613 3.72951 24.3629 3.43395 24.3629V24.3636ZM3.45737 28.6283L2.3323 28.6234C2.10908 28.6227 1.92031 28.434 1.92031 28.2114V24.9155C1.92031 24.6915 2.10839 24.5021 2.33161 24.5021H3.43326C3.65579 24.5021 3.84388 24.6915 3.84457 24.9155V28.2107C3.84457 28.4181 3.68611 28.589 3.45737 28.6283Z" fill="currentColor"/>
            <path d="M3.44012 23.264H2.32607C1.42285 23.264 0.683594 23.9992 0.683594 24.9079V28.217C0.683594 29.1285 1.42216 29.8663 2.32607 29.8615L3.48214 29.856C4.38743 29.8512 5.08121 29.0912 5.08121 28.2176V24.9086C5.08121 23.9985 4.34334 23.2647 3.43943 23.2647L3.44012 23.264ZM3.46836 28.7661L2.33227 28.7612C2.03602 28.7599 1.78317 28.5139 1.78317 28.2114V24.9155C1.78317 24.6144 2.03602 24.3643 2.33227 24.3643H3.43391C3.72948 24.3643 3.98233 24.6144 3.98301 24.9155V28.2108C3.98301 28.4967 3.76117 28.7206 3.46905 28.7667L3.46836 28.7661Z" fill="currentColor"/>
            <path d="M30.9343 16.5267C30.9219 16.5267 30.9102 16.5267 30.8978 16.5274C30.587 16.544 30.2515 16.8078 30.2522 17.2067L30.2536 17.7662C30.2543 18.1237 30.5374 18.4214 30.8978 18.4434C30.9095 18.4441 30.9219 18.4448 30.9336 18.4448C31.2409 18.4448 31.5757 18.2312 31.6039 17.8736C31.6212 17.6594 31.6274 17.441 31.6239 17.2074C31.6184 16.8257 31.3153 16.5267 30.9343 16.5267ZM31.4661 17.8626C31.4413 18.174 31.1196 18.3201 30.9053 18.3063C30.6353 18.2898 30.3914 18.0721 30.3907 17.7662L30.3893 17.2067C30.3893 16.8967 30.6449 16.679 30.904 16.6659C31.2002 16.6507 31.4799 16.8698 31.4854 17.2102C31.4882 17.4114 31.4847 17.6298 31.4655 17.8633L31.4661 17.8626Z" fill="currentColor"/>
            <path d="M30.9048 16.6652C30.6457 16.679 30.3894 16.8967 30.3901 17.206L30.3915 17.7654C30.3915 18.0713 30.6361 18.2891 30.9062 18.3056C31.1204 18.3187 31.4422 18.1733 31.467 17.8619C31.4856 17.6283 31.4897 17.4099 31.487 17.2088C31.4821 16.8691 31.2017 16.6493 30.9055 16.6645L30.9048 16.6652Z" fill="currentColor"/>
          </g>
          <defs>
            <clipPath id="clip0_rbccm_expertise_chart_sae">
              <rect width="32.1992" height="30" fill="white"/>
            </clipPath>
          </defs>
        </svg>
      </xsl:when>
      <xsl:when test="$name = 'search'">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" fill="none" aria-hidden="true">
          <path d="M7.98289 19.3935C6.16741 16.9158 5.35427 13.8439 5.70616 10.7923C6.05805 7.74072 7.54901 4.93455 9.88077 2.9352C12.2125 0.93585 15.2131 -0.109228 18.2822 0.00904609C21.3513 0.12732 24.2626 1.40022 26.4336 3.5731C28.6046 5.74597 29.8752 8.65856 29.9913 11.7282C30.1073 14.7978 29.0603 17.798 27.0595 20.1287C25.0588 22.4593 22.252 23.9485 19.2006 24.2983C16.1492 24.648 13.0782 23.8326 10.6022 22.015H10.604C10.549 22.0901 10.4878 22.1619 10.4203 22.2307L3.20182 29.4502C2.85026 29.8021 2.37334 29.9998 1.87597 30C1.37861 30.0002 0.90155 29.8027 0.549736 29.4511C0.197924 29.0995 0.000177383 28.6225 0 28.1251C-0.000175476 27.6277 0.197235 27.1505 0.5488 26.7987L7.76728 19.5792C7.83428 19.5113 7.90636 19.4505 7.98289 19.3935ZM7.49916 12.1853C7.49916 13.5397 7.76589 14.8808 8.28412 16.1321C8.80236 17.3834 9.56194 18.5204 10.5195 19.4781C11.4771 20.4358 12.6139 21.1955 13.865 21.7138C15.1161 22.2321 16.4571 22.4988 17.8113 22.4988C19.1655 22.4988 20.5064 22.2321 21.7575 21.7138C23.0087 21.1955 24.1455 20.4358 25.103 19.4781C26.0606 18.5204 26.8202 17.3834 27.3384 16.1321C27.8567 14.8808 28.1234 13.5397 28.1234 12.1853C28.1234 9.44996 27.0369 6.82666 25.103 4.89249C23.1691 2.95832 20.5462 1.87172 17.8113 1.87172C15.0763 1.87172 12.4534 2.95832 10.5195 4.89249C8.58561 6.82666 7.49916 9.44996 7.49916 12.1853Z" fill="currentColor"/>
        </svg>
      </xsl:when>
      <xsl:otherwise/>
    </xsl:choose>
  </xsl:template>

  <!-- Render one pillar. -->
  <xsl:template name="renderPillar">
    <xsl:param name="iconName"/>
    <xsl:param name="titleText"/>
    <xsl:param name="titleTag"/>
    <xsl:param name="bodyText"/>
    <xsl:param name="bodyTag"/>
    <xsl:param name="animateDelay"/>

    <div class="rbccm-expertise__pillar" data-animate="fadeInUp">
      <xsl:if test="$animateDelay &gt; 0">
        <xsl:attribute name="data-animate-delay"><xsl:value-of select="$animateDelay"/></xsl:attribute>
      </xsl:if>
      <xsl:if test="$iconName != '' and $iconName != 'none'">
        <span class="rbccm-expertise__pillar-icon" aria-hidden="true">
          <xsl:call-template name="iconSvg">
            <xsl:with-param name="name" select="$iconName"/>
          </xsl:call-template>
        </span>
      </xsl:if>
      <xsl:if test="$titleText != ''">
        <xsl:element name="{$titleTag}">
          <xsl:attribute name="class">rbccm-expertise__pillar-title</xsl:attribute>
          <xsl:value-of select="$titleText"/>
        </xsl:element>
      </xsl:if>
      <xsl:if test="normalize-space($bodyText) != ''">
        <xsl:element name="{$bodyTag}">
          <xsl:attribute name="class">rbccm-expertise__pillar-body</xsl:attribute>
          <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$bodyText"/></xsl:call-template>
        </xsl:element>
      </xsl:if>
    </div>
  </xsl:template>

  <!-- Per-slot lookup + renderPillar dispatcher. -->
  <xsl:template name="renderSlot">
    <xsl:param name="n"/>
    <xsl:variable name="title" select="normalize-space(//Datum[@ID=concat('Pillar', $n, 'TitleText')]/text()[last()])"/>
    <xsl:if test="$title != ''">
      <xsl:variable name="iconRaw"     select="normalize-space(//Datum[@ID=concat('Pillar', $n, 'IconName')]/text()[last()])"/>
      <xsl:variable name="titleTagRaw" select="normalize-space(//Datum[@ID=concat('Pillar', $n, 'TitleTag')]/text()[last()])"/>
      <xsl:variable name="body"        select="//Datum[@ID=concat('Pillar', $n, 'BodyText')]"/>
      <xsl:variable name="bodyTagRaw"  select="normalize-space(//Datum[@ID=concat('Pillar', $n, 'BodyTag')]/text()[last()])"/>

      <xsl:variable name="titleTag">
        <xsl:call-template name="pickTag">
          <xsl:with-param name="raw" select="$titleTagRaw"/>
          <xsl:with-param name="default" select="'h3'"/>
        </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="bodyTag">
        <xsl:call-template name="pickTag">
          <xsl:with-param name="raw" select="$bodyTagRaw"/>
          <xsl:with-param name="default" select="'p'"/>
        </xsl:call-template>
      </xsl:variable>

      <xsl:call-template name="renderPillar">
        <xsl:with-param name="iconName" select="$iconRaw"/>
        <xsl:with-param name="titleText" select="$title"/>
        <xsl:with-param name="titleTag" select="$titleTag"/>
        <xsl:with-param name="bodyText" select="$body"/>
        <xsl:with-param name="bodyTag" select="$bodyTag"/>
        <xsl:with-param name="animateDelay" select="($n - 1) * 150"/>
      </xsl:call-template>
    </xsl:if>
  </xsl:template>


  <xsl:template match="/">

    <xsl:variable name="SECTION_ID"    select="normalize-space(//Datum[@ID='SectionID']/text()[last()])"/>
    <xsl:variable name="SECTION_ARIA"  select="normalize-space(//Datum[@ID='SectionAriaLabel']/text()[last()])"/>
    <xsl:variable name="CSS_PATH"      select="normalize-space(//Datum[@ID='CssPath']/text()[last()])"/>
    <xsl:variable name="JS_PATH"       select="normalize-space(//Datum[@ID='JsPath']/text()[last()])"/>
    <xsl:variable name="CACHE_VERSION" select="normalize-space(//Datum[@ID='CacheVersion']/text()[last()])"/>

    <xsl:variable name="TITLE_TEXT"    select="normalize-space(//Datum[@ID='SectionTitleText']/text()[last()])"/>
    <xsl:variable name="TITLE_TAG_RAW" select="normalize-space(//Datum[@ID='SectionTitleTag']/text()[last()])"/>
    <xsl:variable name="DESC_TEXT"     select="//Datum[@ID='SectionDescriptionText']"/>
    <xsl:variable name="DESC_TAG_RAW"  select="normalize-space(//Datum[@ID='SectionDescriptionTag']/text()[last()])"/>
    <xsl:variable name="HEADER_ALIGN_RAW" select="normalize-space(//Datum[@ID='HeaderAlignment']/text()[last()])"/>
    <xsl:variable name="HEADER_ALIGN">
      <xsl:choose>
        <xsl:when test="$HEADER_ALIGN_RAW = 'center'">center</xsl:when>
        <xsl:otherwise>left</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <xsl:variable name="TITLE_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$TITLE_TAG_RAW"/>
        <xsl:with-param name="default" select="'h2'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="DESC_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$DESC_TAG_RAW"/>
        <xsl:with-param name="default" select="'p'"/>
      </xsl:call-template>
    </xsl:variable>

    <!-- Stylesheet hoist -->
    <xsl:if test="$CSS_PATH != ''">
      <link rel="stylesheet" type="text/css">
        <xsl:attribute name="href">
          <xsl:value-of select="$CSS_PATH"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </link>
    </xsl:if>

    <section>
      <xsl:attribute name="class">rbccm-expertise rbccm-expertise--strategy-and-economics-expertise<xsl:if test="$HEADER_ALIGN = 'center'"> rbccm-expertise--header-center</xsl:if></xsl:attribute>
      <xsl:if test="$SECTION_ID != ''">
        <xsl:attribute name="id"><xsl:value-of select="$SECTION_ID"/></xsl:attribute>
      </xsl:if>
      <xsl:if test="$SECTION_ARIA != ''">
        <xsl:attribute name="aria-label"><xsl:value-of select="$SECTION_ARIA"/></xsl:attribute>
      </xsl:if>

      <div class="rbccm-expertise__inner">

        <div class="rbccm-expertise__header">
          <xsl:if test="$TITLE_TEXT != ''">
            <xsl:element name="{$TITLE_TAG}">
              <xsl:attribute name="class">rbccm-expertise__title</xsl:attribute>
              <xsl:attribute name="data-animate">fadeInUp</xsl:attribute>
              <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$TITLE_TEXT"/></xsl:call-template>
            </xsl:element>
          </xsl:if>
          <xsl:if test="normalize-space($DESC_TEXT) != ''">
            <xsl:element name="{$DESC_TAG}">
              <xsl:attribute name="class">rbccm-expertise__description</xsl:attribute>
              <xsl:attribute name="data-animate">fadeInUp</xsl:attribute>
              <xsl:attribute name="data-animate-delay">250</xsl:attribute>
              <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$DESC_TEXT"/></xsl:call-template>
            </xsl:element>
          </xsl:if>
        </div>

        <div class="rbccm-expertise__sr-only" aria-live="polite" aria-atomic="true"></div>

        <div class="rbccm-expertise__track">
          <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="1"/></xsl:call-template>
          <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="2"/></xsl:call-template>
          <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="3"/></xsl:call-template>
          <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="4"/></xsl:call-template>
        </div>

        <div class="rbccm-expertise__controls">
          <button class="rbccm-expertise__btn rbccm-expertise__btn--prev" type="button" aria-label="Previous item">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="24" viewBox="0 0 14 24" fill="none" aria-hidden="true">
              <path d="M12.3032 1L1.41422 11.889L12.3032 22.778" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </button>
          <div class="rbccm-expertise__dots"></div>
          <button class="rbccm-expertise__btn rbccm-expertise__btn--next" type="button" aria-label="Next item">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="24" viewBox="0 0 14 24" fill="none" aria-hidden="true">
              <path d="M1.69678 1L12.5858 11.889L1.69678 22.778" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </button>
        </div>

      </div>
    </section>

    <xsl:if test="$JS_PATH != ''">
      <script>
        <xsl:attribute name="src">
          <xsl:value-of select="$JS_PATH"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </script>
    </xsl:if>

  </xsl:template>

</xsl:stylesheet>
