/* =========================================================================
   Filter Component (shared)
   -------------------------------------------------------------------------
   Vanilla JS, no dependencies. Self-contained IIFE. Idempotent.

   ---- Container-driven API ---------------------------------------------
   Author provides a single `data-container` selector on the filter root.
   The filter then:
     1. Finds every element inside that container with `[data-search-text]`
        (or a custom selector via `data-item-selector`)
     2. Auto-injects an empty-state block and pagination nav at the end
        of the container (unless the author already placed them there)
     3. Filters + paginates the item set as inputs change

   ---- Dimension-agnostic dropdowns -------------------------------------
   Every dropdown in the filter markup has `data-filter="<dim>"` (e.g.
   "year", "region", "topic", "platform", "conference"). On init the
   JS:
     - Scans all items for unique values of `data-<dim>`
     - Populates the dropdown with one option per unique value
     - If ZERO unique values are found, HIDES the dropdown's wrapper
       entirely (until content ops backfills the tag on articles)

   This means authors can drop any number of dropdowns into the filter
   UI — the JS handles auto-populate, hide-if-empty, and match logic
   without code changes. Add a new filter dimension by:
     1. Adding a <select data-filter="topic"> to the filter markup
     2. Emitting data-topic="..." on the items

   ---- Multi-value item attributes --------------------------------------
   Item data attributes can carry multiple values, whitespace / comma /
   slash separated. e.g. data-topic="healthcare energy-transition"
   or data-region="UK/US". The match logic checks if the selected
   dropdown value is any of the item's split values.

   ---- Region bucketing (special) ---------------------------------------
   The `region` dimension uses bucketing: dropdown values are bucket keys
   (e.g. "europe") that expand to raw ISO codes via REGION_BUCKETS.
   Other dimensions use exact match.

   ---- Data contract on filtered items -----------------------------------
     data-<dim>      value(s) for the dropdown labelled data-filter="<dim>"
     data-search-text lowercased searchable haystack (required to be found)

   ---- Free-text search scope --------------------------------------------
   Search matches data-search-text (title + description) PLUS every
   registered dropdown dimension, so typing "financial" also returns
   everything tagged data-topic="financial-institutions", and "europe"
   returns everything tagged data-region="de".
   Hyphens are flattened to spaces on both the query and the haystack, so
   slugged values match either way ("financial institutions" == the slug).
   Region codes are reverse-mapped to their bucket key + label first, since
   nobody searches "de" — see haystackFor() / regionSearchTerms().

   ---- Plural + synonym handling -----------------------------------------
   Query "financials" would normally miss "financial institutions" because
   the substring match is too literal. normalizeSearch() therefore also:
     1. Applies a phrase-level SEARCH_SYNONYMS lookup (whole-query match)
        so common paraphrases route to the canonical taxonomy label
        (e.g. "financial services" → "financial institutions").
     2. Strips trailing "s" per word so plurals fold onto their singular
        (financials → financial, services → service). Skips short words
        (≤3 chars) and double-s words (class → class, not clas).
   Both are applied to query AND haystack so they stay in sync.
   ========================================================================= */

(function () {
  'use strict';

  var REGION_BUCKETS = {
    'global': ['global'],
    'us':     ['us', 'usa', 'global'],   /* TEMP: US matches Global until DCR adds a real "us" option */
    'canada': ['ca', 'canada'],
    'europe': ['be', 'fr', 'de', 'it', 'ie', 'lu', 'ch', 'gb', 'uk', 'ae', 'europe', 'emea'],
    'apac':   ['au', 'hk', 'my', 'sg', 'apac', 'asia', 'asia-pacific']
  };

  /* Order buckets appear in the Region dropdown. */
  var REGION_ORDER = ['global', 'us', 'canada', 'europe', 'apac'];

  var REGION_LABELS = {
    'global': 'Global',
    'us':     'US',
    'canada': 'Canada',
    'europe': 'Europe',
    'apac':   'APAC'
  };

  /* Known acronyms → keep uppercase in display labels rather than
     title-casing them into "Us", "Apac", etc. */
  var ACRONYM_LABELS = {
    'apac':  'APAC',
    'us':    'US',
    'usa':   'USA',
    'uk':    'UK',
    'ai':    'AI',
    'esg':   'ESG',
    'emea':  'EMEA'
  };

  /* Whole-query synonyms — route common paraphrases to the canonical
     taxonomy phrase so search finds articles tagged under the official
     Topic label. Applied by normalizeSearch() before the plural strip.
     Keys and values are lowercased, hyphen-flattened, whitespace-collapsed
     — i.e. the same shape normalizeSearch produces. Extend as content ops
     identifies gaps between what editors write and what users type. */
  var SEARCH_SYNONYMS = {
    'financial services': 'financial institutions'
  };

  /* Canonical Topic labels — kebab-case DCR values map to human-readable
     labels with proper spaces and ampersands. Matches the July 2 taxonomy
     Joe locked in (9 topics). Add here when new topics land in the DCR. */
  var TOPIC_LABELS = {
    'energy':                          'Energy',
    'energy-transition':               'Energy Transition',
    'financial-institutions':          'Financial Institutions',
    'healthcare':                      'Healthcare',
    'industrials':                     'Industrials',
    'markets-economics':               'Markets & Economics',
    'mining-materials':                'Mining & Materials',
    'power-utilities-infrastructure':  'Power, Utilities & Infrastructure',
    'technology-innovation':           'Technology & Innovation'
  };

  var DEFAULT_STRINGS = {
    emptyHeading:           'No results found',
    emptyMessage:           "We couldn't find any results that match your current filters.",
    emptyMessageEmphasis:   'Try adjusting your filters or search terms.',
    emptyClearLabel:        'Clear filters',
    prevPageLabel:          'Previous page',
    nextPageLabel:          'Next page',
    pageBtnLabel:           'Page {n}',
    ellipsis:               '…'
  };

  var STRING_ATTRS = {
    emptyHeading:           'data-empty-heading',
    emptyMessage:           'data-empty-message',
    emptyMessageEmphasis:   'data-empty-message-emphasis',
    emptyClearLabel:        'data-empty-clear-label',
    prevPageLabel:          'data-prev-page-label',
    nextPageLabel:          'data-next-page-label',
    pageBtnLabel:           'data-page-btn-label',
    ellipsis:               'data-ellipsis'
  };

  var EMPTY_ICON_SVG = '<svg class="rbccm-filter__empty-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 43 43" fill="none" aria-hidden="true">'
    + '<circle cx="17" cy="17" r="12" stroke="currentColor" stroke-width="2.5"/>'
    + '<line x1="25.5" y1="25.5" x2="37" y2="37" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>'
    + '</svg>';

  function fmt(template, vars) {
    return String(template).replace(/\{(\w+)\}/g, function (_, k) {
      return (vars && vars[k] != null) ? vars[k] : '';
    });
  }

  function readStrings(filterRoot) {
    var strings = {};
    for (var key in DEFAULT_STRINGS) {
      if (!DEFAULT_STRINGS.hasOwnProperty(key)) continue;
      var attrVal = filterRoot.getAttribute(STRING_ATTRS[key]);
      strings[key] = (attrVal != null && attrVal !== '') ? attrVal : DEFAULT_STRINGS[key];
    }
    return strings;
  }

  /* Split a raw attribute value into normalized tokens.
     Handles space, comma, and slash separators. Lowercases everything. */
  function tokenize(raw) {
    if (!raw) return [];
    return String(raw).toLowerCase().split(/[\s,\/]+/).filter(Boolean);
  }

  /* Format a raw value into a display label for a given dimension.
     Month YYYY-MM → "Month YYYY". Other dimensions get title-cased with
     hyphens replaced by spaces. */
  function formatValue(value, dim) {
    if (!value) return value;
    /* Year is already display-ready ("2025", "2026") — pass through. */
    if (dim === 'year') {
      return value;
    }
    if (dim === 'region') {
      return REGION_LABELS[value.toLowerCase()] || value;
    }
    if (dim === 'topic') {
      /* Canonical taxonomy label wins so ampersands, commas, and casing
         match Joe's spreadsheet exactly. Falls back to generic title-case
         for unknown topics (new taxonomy entries not yet added to map). */
      return TOPIC_LABELS[value.toLowerCase()] || genericTitleCase(value);
    }
    /* Generic fallback for any other dimension: title-case each word,
       keep known acronyms all-caps ("apac" → "APAC", not "Apac"). */
    return genericTitleCase(value);
  }

  function genericTitleCase(value) {
    return value.replace(/[-_]+/g, ' ').replace(/\S+/g, function (word) {
      var lower = word.toLowerCase();
      if (ACRONYM_LABELS[lower]) return ACRONYM_LABELS[lower];
      return word.charAt(0).toUpperCase() + word.substring(1).toLowerCase();
    });
  }

  function ensureEmptyState(container, isDark) {
    var existing = container.querySelector('.rbccm-filter__empty');
    if (existing) {
      if (isDark) existing.classList.add('rbccm-filter__empty--dark');
      return existing;
    }
    var el = document.createElement('div');
    el.className = 'rbccm-filter__empty' + (isDark ? ' rbccm-filter__empty--dark' : '');
    container.appendChild(el);
    return el;
  }

  function ensurePaginationHost(container) {
    var existing = container.querySelector('.rbccm-filter__pagination-host');
    if (existing) return existing;
    var el = document.createElement('div');
    el.className = 'rbccm-filter__pagination-host';
    container.appendChild(el);
    return el;
  }

  function bindFilter(filterRoot) {
    if (filterRoot.getAttribute('data-filter-bound') === 'true') return;
    filterRoot.setAttribute('data-filter-bound', 'true');

    var strings        = readStrings(filterRoot);
    var isDark         = filterRoot.classList.contains('rbccm-filter--dark');
    var containerSel   = filterRoot.getAttribute('data-container');
    var container      = containerSel ? document.querySelector(containerSel) : null;

    if (!container) {
      console.warn('[rbccm-filter] No container found for selector:', containerSel);
      return;
    }

    var itemSelector   = filterRoot.getAttribute('data-item-selector') || '[data-search-text], [data-title]';
    var pageSize       = parseInt(filterRoot.getAttribute('data-page-size'), 10) || 0;
    /* Optional "when filter is active" page size. Editorial pattern: default
       view shows a hero + few items (page-size=4); active filtering flips
       to a denser utilitarian view (page-size-filtered=6). Falls back to
       the default page size if not set. */
    var filteredPageSize = parseInt(filterRoot.getAttribute('data-page-size-filtered'), 10) || pageSize;
    var allItems       = container.querySelectorAll(itemSelector);
    var emptyState     = ensureEmptyState(container, isDark);
    var paginationHost = ensurePaginationHost(container);

    /* -------- Register every dropdown in the filter markup --------
       Each `.rbccm-filter__select-wrap[data-filter="<dim>"]` gets a
       custom-styled popup listbox built from item data-<dim> values.
       Wrap is hidden if no items carry that attribute. */
    var dropdowns = [];      /* [{ dim, wrap, button, panel, getValue, setValue, close }] */
    var dropdownWraps = filterRoot.querySelectorAll('.rbccm-filter__select-wrap[data-filter]');
    for (var d = 0; d < dropdownWraps.length; d++) {
      var w = dropdownWraps[d];
      var dm = w.getAttribute('data-filter');
      if (!dm || dm === 'search') continue;
      var built = buildCustomDropdown(w, dm);
      if (built) dropdowns.push(built);
    }

    function buildCustomDropdown(wrap, dim) {
      var attrName = 'data-' + dim;
      var button = wrap.querySelector('.rbccm-filter__select');
      if (!button) return null;

      /* Reset any prior inline display state from a previous bind
         (e.g. a rebind after tiles were populated by the feed script —
         the first bind ran on an empty item set and hid the wrap;
         this bind may find data and needs the wrap visible again). */
      wrap.style.display = '';

      /* On rebind, the previous bind's click/keydown listeners are still
         attached to the button. Clone-and-replace drops them so we don't
         stack a second set of listeners (which would fire twice per
         click and net to open+close = no visible change). */
      var freshButton = button.cloneNode(true);
      button.parentNode.replaceChild(freshButton, button);
      button = freshButton;

      /* Collect unique lowercased tokens across all items. */
      var seen = {};
      var rawTokens = [];
      for (var i = 0; i < allItems.length; i++) {
        var tokens = tokenize(allItems[i].getAttribute(attrName) || '');
        for (var t = 0; t < tokens.length; t++) {
          if (!seen[tokens[t]]) {
            seen[tokens[t]] = true;
            rawTokens.push(tokens[t]);
          }
        }
      }

      /* No data for this dimension → hide the whole dropdown. */
      if (rawTokens.length === 0) {
        wrap.style.display = 'none';
        return null;
      }

      /* Region: dropdown options are BUCKETS (Global/US/Canada/Europe/APAC),
         not raw ISO codes. Compute which buckets have at least one matching
         code among the collected tokens. */
      var values;
      if (dim === 'region') {
        values = [];
        for (var b = 0; b < REGION_ORDER.length; b++) {
          var bucketKey = REGION_ORDER[b];
          var codes = REGION_BUCKETS[bucketKey];
          for (var c = 0; c < codes.length; c++) {
            if (seen[codes[c]]) { values.push(bucketKey); break; }
          }
        }
        /* No bucket matched — nothing to show. */
        if (values.length === 0) {
          wrap.style.display = 'none';
          return null;
        }
      } else {
        values = rawTokens.slice();
        /* Sort: year descending (newest first), everything else alphabetical. */
        values.sort();
        if (dim === 'year') values.reverse();
      }

      /* Derive the default label from the button's aria-label (e.g. "Filter
         by topic" → "Topic"). Sourcing from aria-label rather than the
         current visible text is important: if URL params or an earlier
         setValue call have already changed the button's visible text to
         (say) "Energy", rebuilding the dropdown would otherwise capture
         "Energy" as the default and stamp it on the clear-filter option,
         producing a duplicate "Energy" at the top of the list.

         Falls back to the current visible text only if aria-label is
         missing, and to the dimension name last of all. */
      var labelEl = button.querySelector('.rbccm-filter__select-label');
      var ariaLabel = (button.getAttribute('aria-label') || '').replace(/^Filter by\s+/i, '').trim();
      var defaultLabel;
      if (ariaLabel) {
        defaultLabel = ariaLabel.charAt(0).toUpperCase() + ariaLabel.slice(1);
      } else if (labelEl) {
        defaultLabel = labelEl.textContent.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
      } else {
        defaultLabel = dim.charAt(0).toUpperCase() + dim.slice(1);
      }
      if (!labelEl) {
        button.textContent = '';
        labelEl = document.createElement('span');
        labelEl.className = 'rbccm-filter__select-label';
        labelEl.textContent = defaultLabel;
        button.appendChild(labelEl);
      }

      /* Build popup panel. */
      var panel = document.createElement('ul');
      panel.className = 'rbccm-filter__select-panel';
      panel.setAttribute('role', 'listbox');
      panel.setAttribute('aria-label', defaultLabel);
      panel.setAttribute('hidden', 'hidden');

      /* First option clears the filter. */
      panel.appendChild(makeOption('', defaultLabel));
      for (var v = 0; v < values.length; v++) {
        panel.appendChild(makeOption(values[v], formatValue(values[v], dim)));
      }
      wrap.appendChild(panel);

      var options = panel.querySelectorAll('.rbccm-filter__select-option');
      var currentValue = '';
      options[0].setAttribute('aria-selected', 'true');

      function makeOption(value, text) {
        var li = document.createElement('li');
        li.className = 'rbccm-filter__select-option';
        li.setAttribute('role', 'option');
        li.setAttribute('data-value', value);
        li.setAttribute('aria-selected', 'false');
        li.tabIndex = -1;
        li.textContent = text;
        return li;
      }

      function findOption(value) {
        for (var i = 0; i < options.length; i++) {
          if (options[i].getAttribute('data-value') === value) return options[i];
        }
        return null;
      }

      function setValue(value) {
        currentValue = value;
        for (var i = 0; i < options.length; i++) {
          options[i].setAttribute('aria-selected', options[i].getAttribute('data-value') === value ? 'true' : 'false');
        }
        var match = findOption(value);
        labelEl.textContent = (match && value !== '') ? match.textContent : defaultLabel;
      }

      function isOpen() {
        return button.getAttribute('aria-expanded') === 'true';
      }

      function open() {
        closeAllExcept(panel);
        panel.removeAttribute('hidden');
        button.setAttribute('aria-expanded', 'true');
        var focused = panel.querySelector('.rbccm-filter__select-option[aria-selected="true"]') || options[0];
        if (focused) focused.focus();
      }

      function close() {
        panel.setAttribute('hidden', 'hidden');
        button.setAttribute('aria-expanded', 'false');
      }

      /* ---------- Button events ---------- */
      button.addEventListener('click', function (e) {
        e.stopPropagation();
        if (isOpen()) close();
        else open();
      });
      button.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          open();
        } else if (e.key === 'Escape' && isOpen()) {
          e.preventDefault();
          close();
        }
      });

      /* ---------- Option events ---------- */
      for (var o = 0; o < options.length; o++) {
        (function (opt) {
          opt.addEventListener('click', function (e) {
            e.stopPropagation();
            setValue(opt.getAttribute('data-value'));
            close();
            button.focus();
            apply(true);
          });
          opt.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              opt.click();
            } else if (e.key === 'ArrowDown') {
              e.preventDefault();
              (opt.nextElementSibling || options[0]).focus();
            } else if (e.key === 'ArrowUp') {
              e.preventDefault();
              (opt.previousElementSibling || options[options.length - 1]).focus();
            } else if (e.key === 'Home') {
              e.preventDefault();
              options[0].focus();
            } else if (e.key === 'End') {
              e.preventDefault();
              options[options.length - 1].focus();
            } else if (e.key === 'Escape') {
              e.preventDefault();
              close();
              button.focus();
            } else if (e.key === 'Tab') {
              close();
            }
          });
        })(options[o]);
      }

      return {
        dim: dim,
        wrap: wrap,
        button: button,
        panel: panel,
        getValue: function () { return currentValue; },
        setValue: setValue,
        close: close
      };
    }

    /* Close all open panels except the given one. */
    function closeAllExcept(exceptPanel) {
      for (var i = 0; i < dropdowns.length; i++) {
        if (dropdowns[i].panel !== exceptPanel) dropdowns[i].close();
      }
    }

    /* Outside-click closes any open panel. Bound at document level so a
       click anywhere off the wraps dismisses. */
    document.addEventListener('click', function (e) {
      for (var i = 0; i < dropdowns.length; i++) {
        if (!dropdowns[i].wrap.contains(e.target)) dropdowns[i].close();
      }
    });

    var searchInput = filterRoot.querySelector('[data-filter="search"]');
    var resetBtn    = filterRoot.querySelector('.rbccm-filter__reset');
    var currentPage = 0;

    function resetFilters() {
      /* Clear each dropdown via its setValue('') closure, which resets
         currentValue, aria-selected states, and labelEl.textContent to
         the default. Also close any open panel so a mid-interaction
         reset doesn't leave a stray panel visible. Belt-and-suspenders:
         re-query the visible label span from the DOM and force it back
         to the button's aria-label as a fallback in case setValue's
         labelEl closure reference got detached. */
      for (var i = 0; i < dropdowns.length; i++) {
        dropdowns[i].setValue('');
        dropdowns[i].close();
        var btn = dropdowns[i].button;
        if (btn) {
          var lbl = btn.querySelector('.rbccm-filter__select-label');
          var fallback = (btn.getAttribute('aria-label') || '').replace(/^Filter by\s+/i, '');
          if (lbl && fallback) {
            // Capitalize first letter to match default (e.g. "year" → "Year")
            lbl.textContent = fallback.charAt(0).toUpperCase() + fallback.slice(1);
          }
        }
      }
      if (searchInput) searchInput.value = '';
      apply(true);
    }

    /* Search terms and haystacks are normalised the same way: lowercased,
       hyphens flattened to spaces, whitespace collapsed. Dimension values
       are slugs ("financial-institutions markets-economics"), so without
       the hyphen flattening a search for "financial institutions" would
       miss the very items the Topic dropdown returns.

       Also does two matching-friendlier passes:
         1. Whole-query synonym lookup so "financial services" folds to
            "financial institutions" before comparison. Applied to the
            haystack too, harmlessly: an item tagged "financial services"
            would surface under a "financial institutions" query as well.
         2. Trailing-s strip per word so plurals match singulars
            (financials → financial). Skips length ≤3 (spare "as", "is",
            "us", "his") and words ending in "ss" (spare "class"). */
    function stripTrailingS(word) {
      if (word.length <= 3) return word;
      if (word.charAt(word.length - 1) !== 's') return word;
      if (word.charAt(word.length - 2) === 's') return word;
      return word.slice(0, -1);
    }
    function normalizeSearch(raw) {
      var s = String(raw || '').toLowerCase().replace(/-/g, ' ').replace(/\s+/g, ' ').trim();
      if (!s) return '';
      if (SEARCH_SYNONYMS[s]) s = SEARCH_SYNONYMS[s];
      s = s.split(' ').map(stripTrailingS).join(' ');
      return s;
    }

    function getState() {
      var state = { search: searchInput ? normalizeSearch(searchInput.value) : '' };
      for (var i = 0; i < dropdowns.length; i++) {
        state[dropdowns[i].dim] = dropdowns[i].getValue().trim();
      }
      return state;
    }

    /* ---------------------------------------------------------------
       Search haystack
       ---------------------------------------------------------------
       data-search-text is built from title + description only, so the
       taxonomy was invisible to search: typing "financial" returned just
       the articles with the word in their copy, while the Financial
       Institutions dropdown returned every article tagged with it.

       The haystack is therefore the item's text PLUS every registered
       dropdown dimension.

       Region needs translating first. Items carry raw ISO codes
       ("global us", "de"), while the dropdown offers buckets
       (Global/US/Canada/Europe/APAC), so the codes alone are not what
       anyone would type. regionSearchTerms() reverse-maps an item's OWN
       codes to the bucket key + label it belongs to, and folds those in
       alongside the codes.

       Note it maps the item's own codes only — NOT the bucket's full code
       list. Folding in the whole list would put every European code on a
       German article, so searching "uk" would return it. The narrower map
       keeps "europe"/"canada"/"apac" working without that false positive.
       The trade-off: aliases that live only in the bucket list ("emea")
       won't match an item tagged "de". Supporting those means expanding
       the query through the buckets, which is a different mechanism.

       Cached per element: apply() runs on every keystroke, and these
       attributes don't change between renders. Feed re-renders produce new
       elements, which get fresh caches. */
    function regionSearchTerms(raw) {
      var codes = tokenize(raw);
      if (!codes.length) return '';
      var out = codes.slice();
      var seenBucket = {};
      for (var b = 0; b < REGION_ORDER.length; b++) {
        var bucketKey = REGION_ORDER[b];
        var bucketCodes = REGION_BUCKETS[bucketKey] || [];
        for (var c = 0; c < bucketCodes.length; c++) {
          if (codes.indexOf(bucketCodes[c]) === -1) continue;
          if (seenBucket[bucketKey]) break;
          seenBucket[bucketKey] = true;
          out.push(bucketKey);
          if (REGION_LABELS[bucketKey]) out.push(REGION_LABELS[bucketKey]);
          break;
        }
      }
      return out.join(' ');
    }

    function haystackFor(item) {
      if (item.__rbccmHaystack) return item.__rbccmHaystack;
      var parts = [item.getAttribute('data-search-text') || item.getAttribute('data-title') || ''];
      for (var i = 0; i < dropdowns.length; i++) {
        var dim = dropdowns[i].dim;
        var raw = item.getAttribute('data-' + dim) || '';
        parts.push(dim === 'region' ? regionSearchTerms(raw) : raw);
      }
      item.__rbccmHaystack = normalizeSearch(parts.join(' '));
      return item.__rbccmHaystack;
    }

    /* Region gets special bucketing via REGION_BUCKETS. */
    function matchesRegion(itemRegions, selectedBucket) {
      if (!selectedBucket) return true;
      var bucketKey = selectedBucket.toLowerCase();
      var codes = REGION_BUCKETS[bucketKey];
      if (!codes) return itemRegions.indexOf(bucketKey) !== -1;
      for (var i = 0; i < codes.length; i++) {
        if (itemRegions.indexOf(codes[i]) !== -1) return true;
      }
      return false;
    }

    /* Generic exact-match: any of the item's tokens for this dimension
       equals the selected dropdown value. */
    function matchesDim(item, dim, selectedValue) {
      if (!selectedValue) return true;
      var tokens = tokenize(item.getAttribute('data-' + dim) || '');
      return tokens.indexOf(selectedValue.toLowerCase()) !== -1;
    }

    function computeMatches() {
      var state = getState();
      var matched = [];
      var unmatched = [];

      for (var i = 0; i < allItems.length; i++) {
        var item = allItems[i];
        var pass = true;

        /* Iterate every registered dropdown. */
        for (var d = 0; d < dropdowns.length; d++) {
          var dim = dropdowns[d].dim;
          var val = state[dim];
          if (!val) continue;

          if (dim === 'region') {
            var itemRegions = tokenize(item.getAttribute('data-region') || '');
            if (!matchesRegion(itemRegions, val)) { pass = false; break; }
          } else {
            if (!matchesDim(item, dim, val)) { pass = false; break; }
          }
        }

        if (pass && state.search) {
          if (haystackFor(item).indexOf(state.search) === -1) pass = false;
        }

        if (pass) matched.push(item);
        else unmatched.push(item);
      }

      return { state: state, matched: matched, unmatched: unmatched };
    }

    function paginate(matched, unmatched, isFiltered) {
      for (var u = 0; u < unmatched.length; u++) unmatched[u].setAttribute('hidden', 'hidden');

      /* Mixed page sizes for the editorial pattern:
           - Unfiltered page 1: `pageSize` (default 4 — featured hero + 3).
           - Unfiltered page 2+: `filteredPageSize` (default 6 — dense 3x2).
           - Any filtered page: `filteredPageSize` (dense grid).
         The featured tile only exists as the first item, so once you
         leave page 1 there's no hero to anchor the hero layout anyway —
         switching to the dense page size gives a clean 3-up grid.

         When either size is 0/unset we degrade gracefully to a single page. */
      var heroSize  = pageSize > 0 ? pageSize : matched.length;
      var denseSize = filteredPageSize > 0 ? filteredPageSize : (pageSize > 0 ? pageSize : matched.length);

      var totalPages;
      var start, end;

      if (isFiltered) {
        /* Uniform dense pages. */
        totalPages = denseSize > 0 ? Math.ceil(matched.length / denseSize) : 1;
        if (currentPage >= totalPages) currentPage = Math.max(0, totalPages - 1);
        start = currentPage * denseSize;
        end   = start + denseSize;
      } else {
        /* Mixed: first page = heroSize, remaining pages = denseSize. */
        if (matched.length <= heroSize) {
          totalPages = 1;
        } else {
          totalPages = 1 + Math.ceil((matched.length - heroSize) / denseSize);
        }
        if (currentPage >= totalPages) currentPage = Math.max(0, totalPages - 1);

        if (currentPage === 0) {
          start = 0;
          end   = heroSize;
        } else {
          start = heroSize + (currentPage - 1) * denseSize;
          end   = start + denseSize;
        }
      }

      for (var m = 0; m < matched.length; m++) {
        if (m >= start && m < end) matched[m].removeAttribute('hidden');
        else matched[m].setAttribute('hidden', 'hidden');
      }

      /* The featured-hero layout only makes sense on page 1 unfiltered,
         since the featured tile is index 0. Mirror the `is-filtered`
         class as `is-past-first-page` on page 2+ so the CSS grid can
         collapse the hero back to a plain tile without needing a new
         selector convention. */
      if (!isFiltered && currentPage > 0) {
        container.classList.add('is-past-first-page');
      } else {
        container.classList.remove('is-past-first-page');
      }

      renderPagination(totalPages);
    }

    function anyFilterActive(state) {
      if (state.search) return true;
      for (var d = 0; d < dropdowns.length; d++) {
        if (state[dropdowns[d].dim]) return true;
      }
      return false;
    }

    function apply(resetPage) {
      if (resetPage) currentPage = 0;
      var r = computeMatches();
      var isFiltered = anyFilterActive(r.state);

      /* Toggle `is-filtered` BEFORE paginate so CSS + pagination see the
         same state (e.g. neutralize featured-tile layout + swap page size
         when active filtering flips the list into a denser view). */
      if (isFiltered) container.classList.add('is-filtered');
      else container.classList.remove('is-filtered');

      paginate(r.matched, r.unmatched, isFiltered);
      renderEmptyState(r.matched.length === 0 && isFiltered);

      /* Sync URL. Filter changes use replaceState (no history bloat as
         the user tries combos). Pagination handlers below use pushState
         so back button walks page steps. Init call uses replaceState. */
      writeUrlState(false);
    }


    /* ---------- URL param sync ----------
       Deep-link support. Reads state from
       ?year=…&region=…&topic=…&search=…&page=… on load, writes it back
       on every filter/page change. Popstate re-applies from URL so
       browser back/forward works.

       Param names match dimension keys 1:1 (year, region, topic — whatever
       the filter's dropdown data-dim attributes are), plus `search` for
       the search input and `page` for the 1-indexed page number. All
       values lowercase for readable, shareable URLs. */
    function writeUrlState(pushHistory) {
      if (!window.history || !window.URLSearchParams) return;
      try {
        var params = new URLSearchParams(window.location.search);
        var owned = ['search', 'page'];
        for (var i = 0; i < dropdowns.length; i++) owned.push(dropdowns[i].dim.toLowerCase());
        for (var j = 0; j < owned.length; j++) params.delete(owned[j]);

        for (var k = 0; k < dropdowns.length; k++) {
          var v = (dropdowns[k].getValue() || '').trim();
          if (v) params.set(dropdowns[k].dim.toLowerCase(), v);
        }
        if (searchInput && searchInput.value && searchInput.value.trim()) {
          params.set('search', searchInput.value.trim());
        }
        if (currentPage > 0) params.set('page', String(currentPage + 1));

        var query = params.toString();
        var newUrl = window.location.pathname + (query ? '?' + query : '') + window.location.hash;
        var method = pushHistory ? 'pushState' : 'replaceState';
        window.history[method]({ page: currentPage }, '', newUrl);
      } catch (e) { /* sandboxed iframes / older browsers — silent fail */ }
    }

    function readUrlState() {
      if (!window.URLSearchParams) return;
      var params = new URLSearchParams(window.location.search);
      for (var i = 0; i < dropdowns.length; i++) {
        var val = params.get(dropdowns[i].dim.toLowerCase());
        if (val !== null) dropdowns[i].setValue(val);
      }
      if (searchInput) {
        var s = params.get('search');
        if (s !== null) searchInput.value = s;
      }
      var p = parseInt(params.get('page'), 10);
      if (!isNaN(p) && p > 0) currentPage = p - 1;
    }

    /* Back / forward — re-apply state from the URL that the browser
       just restored. Don't reset page — the URL is authoritative. */
    window.addEventListener('popstate', function () {
      readUrlState();
      apply(false);
    });

    /* ---------- Empty state ---------- */
    function renderEmptyState(show) {
      if (!show) {
        emptyState.classList.remove('is-visible');
        emptyState.innerHTML = '';
        return;
      }

      emptyState.classList.add('is-visible');
      emptyState.innerHTML = '';

      var iconWrap = document.createElement('div');
      iconWrap.className = 'rbccm-filter__empty-icon-wrap';
      iconWrap.setAttribute('aria-hidden', 'true');
      iconWrap.innerHTML = EMPTY_ICON_SVG;
      emptyState.appendChild(iconWrap);

      if (strings.emptyHeading) {
        var heading = document.createElement('h3');
        heading.className = 'rbccm-filter__empty-heading';
        heading.textContent = strings.emptyHeading;
        emptyState.appendChild(heading);
      }
      if (strings.emptyMessage) {
        var msg1 = document.createElement('p');
        msg1.className = 'rbccm-filter__empty-message';
        msg1.textContent = strings.emptyMessage;
        emptyState.appendChild(msg1);
      }
      if (strings.emptyMessageEmphasis) {
        var msg2 = document.createElement('p');
        msg2.className = 'rbccm-filter__empty-message rbccm-filter__empty-message--emphasis';
        msg2.textContent = strings.emptyMessageEmphasis;
        emptyState.appendChild(msg2);
      }
      if (strings.emptyClearLabel) {
        var clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'rbccm-filter__empty-clear';
        clearBtn.textContent = strings.emptyClearLabel;
        clearBtn.addEventListener('click', resetFilters);
        emptyState.appendChild(clearBtn);
      }
    }

    /* ---------- Pagination controls ---------- */
    function renderPagination(totalPages) {
      if (pageSize <= 0) return;
      paginationHost.innerHTML = '';
      if (totalPages <= 1) return;

      var nav = document.createElement('nav');
      nav.className = 'rbccm-filter__pagination';
      nav.setAttribute('aria-label', 'Pagination');

      nav.appendChild(buildArrowBtn('prev', currentPage === 0));
      var pages = computePageList(currentPage, totalPages);
      for (var i = 0; i < pages.length; i++) {
        if (pages[i] === '…') {
          var el = document.createElement('span');
          el.className = 'rbccm-filter__page-ellipsis';
          el.setAttribute('aria-hidden', 'true');
          el.textContent = strings.ellipsis;
          nav.appendChild(el);
        } else {
          nav.appendChild(buildPageBtn(pages[i]));
        }
      }
      nav.appendChild(buildArrowBtn('next', currentPage >= totalPages - 1));
      paginationHost.appendChild(nav);
    }

    /* Responsive target circle count. Odd numbers keep the current-page
       chip visually centered when it's in the middle of the range:
         - Mobile   (<768px): 7 max, degrades to 5 when total ≤ 5
         - Tablet   (768-1023): 9 max
         - Desktop  (≥1024): 11 max
       Fall back to 7 when window is unavailable (SSR/pre-hydrate). */
    function getTargetPageCount() {
      if (typeof window === 'undefined' || !window.matchMedia) return 7;
      if (window.matchMedia('(min-width: 1024px)').matches) return 11;
      if (window.matchMedia('(min-width: 768px)').matches) return 9;
      return 7;
    }

    function computePageList(current, total) {
      var target = getTargetPageCount();

      /* Total fits in the window — show every page, no ellipsis. */
      if (total <= target) {
        var all = [];
        for (var i = 0; i < total; i++) all.push(i);
        return all;
      }

      /* Reserve 4 slots for first + last + two ellipses, then a
         centered window of the remaining N pages around current. */
      var windowSize = target - 4;
      var half = Math.floor(windowSize / 2);
      var out;

      /* Near start — no left ellipsis, extend right window. */
      if (current <= half + 1) {
        out = [];
        for (var i = 0; i < target - 2; i++) out.push(i);
        out.push('…');
        out.push(total - 1);
        return out;
      }

      /* Near end — no right ellipsis, extend left window. */
      if (current >= total - half - 2) {
        out = [0, '…'];
        for (var i = total - (target - 2); i < total; i++) out.push(i);
        return out;
      }

      /* Middle — both ellipses, current centered inside window. */
      out = [0, '…'];
      for (var i = current - half; i <= current + half; i++) out.push(i);
      out.push('…');
      out.push(total - 1);
      return out;
    }

    /* ---------- Scroll to first visible result after pagination ----------
       On page change (page number or prev/next arrow), smooth-scroll the
       viewport so the first visible item in the current page is at the
       top of the results area. Prevents users landing mid-page after
       clicking "Page 3" and having to hunt for where the new tiles start.

       Filter changes do NOT trigger this — user's eye is already at the
       filter when they interact, and the results updating in place is
       the expected micro-iteration flow.

       Respects prefers-reduced-motion: skips animation, jumps instantly.

       Offset for sticky headers is handled via CSS `scroll-margin-top`
       on the target element — set it in the consuming component's CSS
       if the page has a fixed top bar. */
    function scrollToFirstResult() {
      /* Default: scroll to the filter root itself. Puts the filter bar
         at the top of the viewport with the first result of the new
         page immediately below — user has both the controls they just
         used and the fresh content in a single glance.

         Override with [data-scroll-target="#some-id"] on the filter root
         if the page prefers landing somewhere else. */
      var targetSelector = filterRoot.getAttribute('data-scroll-target');
      var target = targetSelector ? document.querySelector(targetSelector) : filterRoot;
      if (!target) return;

      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
    }

    /* ---------- Focus retention after pagination clicks ----------
       paginate() rebuilds the entire nav on every click, so the button
       the user just activated is destroyed and replaced. Without help,
       focus drops to <body> — keyboard users get dumped mid-navigation.
       These helpers restore focus to the equivalent button after
       re-render, preserving the "focus stays on the thing I clicked"
       expectation that lets keyboard users rapid-fire pagination. */
    /* All focus() calls in these helpers pass { preventScroll: true } so
       the browser's default "scroll focused element into view" doesn't
       yank the viewport back down and undo scrollToFirstResult's
       scroll-to-top. Focus semantics preserved, scroll semantics owned
       entirely by scrollToFirstResult. */
    function focusRebuiltPageBtn(pageIndex) {
      var buttons = paginationHost.querySelectorAll('.rbccm-filter__page-btn:not(.rbccm-filter__page-btn--prev):not(.rbccm-filter__page-btn--next)');
      /* Match by the button label (page number, 1-indexed). */
      var target = String(pageIndex + 1);
      for (var i = 0; i < buttons.length; i++) {
        if (buttons[i].textContent === target) { buttons[i].focus({ preventScroll: true }); return; }
      }
    }

    function focusRebuiltArrowBtn(dir) {
      var arrow = paginationHost.querySelector('.rbccm-filter__page-btn--' + dir);
      /* If the arrow is now disabled (reached start/end of range), fall
         back to the newly-current page number so focus doesn't land on
         an unreachable control. */
      if (arrow && !arrow.hasAttribute('disabled')) { arrow.focus({ preventScroll: true }); return; }
      var active = paginationHost.querySelector('.rbccm-filter__page-btn--active');
      if (active) active.focus({ preventScroll: true });
    }

    function buildPageBtn(pageIndex) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'rbccm-filter__page-btn';
      if (pageIndex === currentPage) {
        btn.className += ' rbccm-filter__page-btn--active';
        btn.setAttribute('aria-current', 'page');
      }
      btn.textContent = String(pageIndex + 1);
      btn.setAttribute('aria-label', fmt(strings.pageBtnLabel, { n: pageIndex + 1 }));
      btn.addEventListener('click', function () {
        if (pageIndex === currentPage) return;
        currentPage = pageIndex;
        var r = computeMatches();
        paginate(r.matched, r.unmatched, anyFilterActive(r.state));
        writeUrlState(true); // pushState — back button walks page steps
        scrollToFirstResult();
        focusRebuiltPageBtn(pageIndex);
      });
      return btn;
    }

    function buildArrowBtn(dir, disabled) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'rbccm-filter__page-btn rbccm-filter__page-btn--' + dir;
      btn.setAttribute('aria-label', dir === 'prev' ? strings.prevPageLabel : strings.nextPageLabel);
      /* Chevron SVG — 14x24 viewBox from the RBC design spec. Base path
         is a right-facing chevron; prev mirrors it horizontally to point
         left. stroke="currentColor" so hover/focus/dark/disabled states
         adapt automatically. */
      var chevronPath = dir === 'prev'
        ? 'M13 1L2.111 11.889L13 22.778'
        : 'M1 1L11.889 11.889L1 22.778';
      btn.innerHTML =
        '<svg class="rbccm-filter__page-btn-icon" width="14" height="24" viewBox="0 0 14 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">' +
          '<path d="' + chevronPath + '" stroke="currentColor" stroke-width="2" stroke-linecap="round" />' +
        '</svg>';
      if (disabled) btn.setAttribute('disabled', 'disabled');
      btn.addEventListener('click', function () {
        if (dir === 'prev' && currentPage > 0) currentPage--;
        if (dir === 'next') currentPage++;
        var r = computeMatches();
        paginate(r.matched, r.unmatched, anyFilterActive(r.state));
        writeUrlState(true); // pushState — back button walks page steps
        scrollToFirstResult();
        focusRebuiltArrowBtn(dir);
      });
      return btn;
    }

    /* ---------- Event wiring ----------
       Dropdowns already call apply(true) from their option-click
       handler in buildCustomDropdown; no extra listener needed. */
    if (searchInput) {
      searchInput.addEventListener('input', function () { apply(true); });
      searchInput.addEventListener('search', function () { apply(true); });
    }
    if (resetBtn) resetBtn.addEventListener('click', resetFilters);

    /* Re-render pagination when the viewport crosses a breakpoint so the
       circle count adapts (mobile 7 → tablet 9 → desktop 11). Debounced
       so drag-resizes don't rebuild the DOM on every frame; matchMedia
       fires the callback once per crossing, resize fires continuously so
       we throttle it. Skipped when pageSize <= 0 (no pagination in play). */
    var resizeRaf = 0;
    function onViewportChange() {
      if (resizeRaf) return;
      resizeRaf = window.requestAnimationFrame(function () {
        resizeRaf = 0;
        apply(false);
      });
    }
    if (typeof window !== 'undefined' && window.addEventListener) {
      window.addEventListener('resize', onViewportChange);
    }

    /* Hydrate filter + page state from the URL BEFORE the first apply()
       so a deep link like ?year=2026&region=us&page=3 lands directly
       on that filtered page instead of flashing page 1 first. */
    readUrlState();
    apply(false);

    /* Signal to consumer CSS that the filter has initialized and tiles
       are in their correct visible/hidden state. Consumers can hide the
       tile grid (opacity 0) + show a skeleton state until this attribute
       lands, then cross-fade to the real tiles — kills the "everything
       flashes then re-renders" moment on page load. */
    container.setAttribute('data-filter-ready', 'true');
  }

  function init() {
    var roots = document.querySelectorAll('.rbccm-filter');
    for (var i = 0; i < roots.length; i++) bindFilter(roots[i]);
  }

  /* When another script (e.g. conference-insights-tiles-feed.js) populates
     tiles into a filter's target container AFTER our initial bind,
     unbind and re-bind the matching filter root(s) so the dropdowns pick
     up the fresh items. Safe no-op for filters bound to a container
     that isn't the event's target. */
  function rebindFilterForContainer(container) {
    if (!container) return;
    var roots = document.querySelectorAll('.rbccm-filter[data-container]');
    for (var i = 0; i < roots.length; i++) {
      var sel = roots[i].getAttribute('data-container');
      if (!sel) continue;
      var target = document.querySelector(sel);
      if (target !== container) continue;
      /* Reset bound flag and clear any listbox/popup panels the previous
         bind attached so bindFilter can build fresh dropdowns from the
         new item set. */
      roots[i].removeAttribute('data-filter-bound');
      var panels = roots[i].querySelectorAll('.rbccm-filter__select-panel');
      for (var p = 0; p < panels.length; p++) panels[p].parentNode.removeChild(panels[p]);
      bindFilter(roots[i]);
    }
  }

  /* Listen for the tiles-populated signal. Bubbles up from the tiles
     container, so we listen at the document level. */
  document.addEventListener('rbccm:tiles-populated', function (e) {
    var target = e.target;
    rebindFilterForContainer(target);
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
