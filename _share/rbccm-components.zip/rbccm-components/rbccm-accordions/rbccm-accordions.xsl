<?xml version="1.0" encoding="UTF-8"?>
<!--
  RBCCM Accordions - XSL skin
  ==============================================================
  Renders a Preset-driven accordion-section. One variant supported
  today (strategy-and-economics-notes); more can be added by
  appending xsl:when branches inside the Preset routing block.

  Semantic tag picker
  ==============================================================
  Every editable text field ships with a companion Tag Datum
  (h1..h6, p, div, span). The XSL emits the chosen tag via
  xsl:element name="{...}" so authors can pick per-field semantics
  without touching the skin. A pickTag named template guards the
  value: anything outside the allow-list falls back to a safe
  default so a mis-typed Datum never emits garbage markup.

  Repeater
  ==============================================================
  8 note slots exposed. A slot renders when its CategoryText or
  TitleText Datum is filled, so authors leave later slots empty for
  shorter lists. Every other field is left out when blank. A renderNote named template holds the per-slot
  markup so a single body handles every slot without duplication.
-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:output method="html" indent="no" omit-xml-declaration="yes"/>

  <!-- Tag allow-list guard. -->
  <!-- Rich text output. Text pasted into the editor straight from Figma
       carries two hidden spans (data-metadata="(figmeta)..." and
       data-buffer="(figma)...") holding the Figma file key and a base64
       copy of the design, often tens of KB per field. They are invisible
       but bloat the page and expose internal file details, so they are
       removed here; all other HTML is output as entered. -->
  <xsl:template name="rbccmRich">
    <xsl:param name="s"/>
    <xsl:variable name="clean"><xsl:call-template name="rbccmStripFigma"><xsl:with-param name="s" select="string($s)"/></xsl:call-template></xsl:variable>
    <xsl:value-of select="$clean" disable-output-escaping="yes"/>
  </xsl:template>

  <xsl:template name="rbccmStripFigma">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, '&lt;span data-metadata=') and contains(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-metadata='), substring-after(substring-after($s, '&lt;span data-metadata='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="contains($s, '&lt;span data-buffer=') and contains(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;')">
        <xsl:call-template name="rbccmStripFigma">
          <xsl:with-param name="s" select="concat(substring-before($s, '&lt;span data-buffer='), substring-after(substring-after($s, '&lt;span data-buffer='), '&lt;/span&gt;'))"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <xsl:template name="pickTag">
    <xsl:param name="raw"/>
    <xsl:param name="default"/>
    <xsl:choose>
      <xsl:when test="$raw = 'h1' or $raw = 'h2' or $raw = 'h3' or $raw = 'h4' or $raw = 'h5' or $raw = 'h6' or $raw = 'p' or $raw = 'div' or $raw = 'span'">
        <xsl:value-of select="$raw"/>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$default"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Visible text of a rich-text value (tags stripped). -->
  <xsl:template name="stripTags">
    <xsl:param name="s"/>
    <xsl:choose>
      <xsl:when test="contains($s, '&lt;') and contains(substring-after($s, '&lt;'), '&gt;')">
        <xsl:value-of select="substring-before($s, '&lt;')"/>
        <xsl:call-template name="stripTags">
          <xsl:with-param name="s" select="substring-after(substring-after($s, '&lt;'), '&gt;')"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:otherwise><xsl:value-of select="$s"/></xsl:otherwise>
    </xsl:choose>
  </xsl:template>

  <!-- Returns 'yes' when a rich-text field has visible text. The editor
       leaves placeholders like <p><br data-mce-bogus="1"></p> or
       <p>&nbsp;</p> in a field that looks empty; those count as blank
       so no empty tag is rendered. -->
  <xsl:template name="hasText">
    <xsl:param name="s"/>
    <xsl:variable name="plain"><xsl:call-template name="stripTags"><xsl:with-param name="s" select="$s"/></xsl:call-template></xsl:variable>
    <xsl:if test="normalize-space(translate($plain, '&#160;&amp;nbsp;', '')) != ''">yes</xsl:if>
  </xsl:template>

  <!-- Toggle icon: a single plus SVG whose fill inherits from the
       button's currentColor. CSS rotates it 45deg clockwise on
       .is-open (a symmetric plus becomes an X visually) and swaps
       the button's color from warm yellow to bright blue. One SVG,
       one animation - no SVG swap machinery required. -->
  <xsl:template name="toggleIcon">
    <svg class="rbccm-accordions__item-toggle-icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M9 2C9 1.44687 8.55312 1 8 1C7.44688 1 7 1.44687 7 2V7H2C1.44687 7 1 7.44688 1 8C1 8.55312 1.44687 9 2 9H7V14C7 14.5531 7.44688 15 8 15C8.55312 15 9 14.5531 9 14V9H14C14.5531 9 15 8.55312 15 8C15 7.44688 14.5531 7 14 7H9V2Z" fill="currentColor"/>
    </svg>
  </xsl:template>
  <!-- Chevron + shaft arrow (13x13). Stroke uses currentColor so
       the variant modifier's color rule on .__item-readmore
       repaints text + icon in one place. -->
  <xsl:template name="readMoreArrow">
    <svg class="rbccm-accordions__item-readmore-icon" xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
      <path d="M2.70801 6.5H10.2913" stroke="currentColor" stroke-width="1.08333" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M6.5 2.70831L10.2917 6.49998L6.5 10.2916" stroke="currentColor" stroke-width="1.08333" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </xsl:template>

  <!-- Render one note slot. Params are resolved from Datums in the
       caller so this template stays generic across slots. -->
  <xsl:template name="renderNote">
    <xsl:param name="idx"/>
    <xsl:param name="sectionId"/>
    <xsl:param name="categoryText"/>
    <xsl:param name="categoryTag"/>
    <xsl:param name="author"/>
    <xsl:param name="date"/>
    <xsl:param name="titleText"/>
    <xsl:param name="titleTag"/>
    <xsl:param name="summaryText"/>
    <xsl:param name="summaryTag"/>
    <xsl:param name="bodyHtml"/>
    <xsl:param name="readMoreLabel"/>
    <xsl:param name="readMoreHref"/>
    <xsl:param name="readMoreAria"/>

    <xsl:variable name="hasSummary"><xsl:call-template name="hasText"><xsl:with-param name="s" select="$summaryText"/></xsl:call-template></xsl:variable>
    <xsl:variable name="bodyHasText"><xsl:call-template name="hasText"><xsl:with-param name="s" select="$bodyHtml"/></xsl:call-template></xsl:variable>
    <!-- A body that is only a video / podcast embed has no text but
         still counts as content. -->
    <xsl:variable name="bodyLower" select="translate($bodyHtml, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')"/>
    <xsl:variable name="hasBody">
      <xsl:if test="$bodyHasText = 'yes' or contains($bodyLower, '&lt;iframe') or contains($bodyLower, '&lt;video') or contains($bodyLower, '&lt;audio') or contains($bodyLower, '&lt;img') or contains($bodyLower, '&lt;embed') or contains($bodyLower, '&lt;object')">yes</xsl:if>
    </xsl:variable>
    <!-- Name used in the toggle's label; falls back to the category
         when the title is blank. -->
    <xsl:variable name="noteName">
      <xsl:choose>
        <xsl:when test="$titleText != ''"><xsl:value-of select="$titleText"/></xsl:when>
        <xsl:otherwise><xsl:value-of select="$categoryText"/></xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <xsl:variable name="expandedId">
      <xsl:value-of select="$sectionId"/>-item-<xsl:value-of select="$idx"/>-body
    </xsl:variable>

    <article class="rbccm-accordions__item">
      <div class="rbccm-accordions__item-header">
        <div class="rbccm-accordions__item-meta">
          <xsl:if test="$categoryText != ''">
            <xsl:element name="{$categoryTag}">
              <xsl:attribute name="class">rbccm-accordions__item-eyebrow</xsl:attribute>
              <xsl:value-of select="$categoryText"/>
            </xsl:element>
          </xsl:if>
          <xsl:if test="$author != '' or $date != ''">
            <p class="rbccm-accordions__item-byline">
              <xsl:value-of select="$author"/>
              <xsl:if test="$author != '' and $date != ''"><xsl:text> | </xsl:text></xsl:if>
              <xsl:value-of select="$date"/>
            </p>
          </xsl:if>
        </div>
        <!-- No toggle when there is nothing to expand (no body copy
             and no read-more link). -->
        <xsl:if test="$hasBody = 'yes' or $readMoreLabel != ''">
          <button type="button" class="rbccm-accordions__item-toggle" aria-expanded="false">
            <xsl:attribute name="aria-controls"><xsl:value-of select="normalize-space($expandedId)"/></xsl:attribute>
            <xsl:attribute name="aria-label">Expand note: <xsl:value-of select="$noteName"/></xsl:attribute>
            <xsl:call-template name="toggleIcon"/>
          </button>
        </xsl:if>
      </div>

      <xsl:if test="$titleText != '' or $hasSummary = 'yes'">
        <div class="rbccm-accordions__item-body">
          <xsl:if test="$titleText != ''">
            <xsl:element name="{$titleTag}">
              <xsl:attribute name="class">rbccm-accordions__item-title</xsl:attribute>
              <xsl:value-of select="$titleText"/>
            </xsl:element>
          </xsl:if>
          <xsl:if test="$hasSummary = 'yes'">
            <xsl:element name="{$summaryTag}">
              <xsl:attribute name="class">rbccm-accordions__item-summary</xsl:attribute>
              <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$summaryText"/></xsl:call-template>
            </xsl:element>
          </xsl:if>
        </div>
      </xsl:if>

      <xsl:if test="$hasBody = 'yes' or $readMoreLabel != ''">
        <div class="rbccm-accordions__item-expanded" role="region">
          <xsl:attribute name="id"><xsl:value-of select="normalize-space($expandedId)"/></xsl:attribute>
          <xsl:if test="$hasBody = 'yes'">
            <div class="rbccm-accordions__item-expanded-copy">
              <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$bodyHtml"/></xsl:call-template>
            </div>
          </xsl:if>
          <xsl:if test="$readMoreLabel != ''">
            <a class="rbccm-accordions__item-readmore">
              <xsl:attribute name="href"><xsl:value-of select="$readMoreHref"/></xsl:attribute>
              <!-- aria-label ALWAYS emitted so bare "Read more" links announce
                   what they lead to. Prefer the explicit Datum override; fall
                   back to composing "{label}: {note title}" so screen readers
                   hear "Read more: Fiscal outlook 2026" not just "Read more". -->
              <xsl:attribute name="aria-label">
                <xsl:choose>
                  <xsl:when test="$readMoreAria != ''"><xsl:value-of select="$readMoreAria"/></xsl:when>
                  <xsl:when test="$titleText != ''"><xsl:value-of select="$readMoreLabel"/>: <xsl:value-of select="$titleText"/></xsl:when>
                  <xsl:otherwise><xsl:value-of select="$readMoreLabel"/></xsl:otherwise>
                </xsl:choose>
              </xsl:attribute>
              <xsl:value-of select="$readMoreLabel"/>
              <xsl:call-template name="readMoreArrow"/>
            </a>
          </xsl:if>
        </div>
      </xsl:if>
    </article>
  </xsl:template>


  <!-- text()[last()] isolates the trailing text of a Datum whose
       body may contain child Option elements. -->
  <xsl:template match="/">

    <!-- Shared -->
    <xsl:variable name="SECTION_ID"    select="normalize-space(//Datum[@ID='SectionID']/text()[last()])"/>
    <xsl:variable name="SECTION_ARIA"  select="normalize-space(//Datum[@ID='SectionAriaLabel']/text()[last()])"/>
    <xsl:variable name="CSS_PATH"      select="normalize-space(//Datum[@ID='CssPath']/text()[last()])"/>
    <xsl:variable name="JS_PATH"       select="normalize-space(//Datum[@ID='JsPath']/text()[last()])"/>
    <xsl:variable name="CACHE_VERSION" select="normalize-space(//Datum[@ID='CacheVersion']/text()[last()])"/>
    <xsl:variable name="PRESET"        select="normalize-space(//Datum[@ID='Preset']/text()[last()])"/>

    <!-- Section header -->
    <xsl:variable name="TITLE_TEXT"   select="normalize-space(//Datum[@ID='SectionTitleText']/text()[last()])"/>
    <xsl:variable name="TITLE_TAG_RAW" select="normalize-space(//Datum[@ID='SectionTitleTag']/text()[last()])"/>
    <xsl:variable name="DESC_TEXT"    select="//Datum[@ID='SectionDescriptionText']"/>
    <xsl:variable name="DESC_TAG_RAW" select="normalize-space(//Datum[@ID='SectionDescriptionTag']/text()[last()])"/>
    <xsl:variable name="EXPAND_LABEL"   select="normalize-space(//Datum[@ID='ExpandAllLabel']/text()[last()])"/>
    <xsl:variable name="COLLAPSE_LABEL" select="normalize-space(//Datum[@ID='CollapseAllLabel']/text()[last()])"/>
    <xsl:variable name="EXPAND_TEXT">
      <xsl:choose>
        <xsl:when test="$EXPAND_LABEL != ''"><xsl:value-of select="$EXPAND_LABEL"/></xsl:when>
        <xsl:otherwise>Expand all</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="COLLAPSE_TEXT">
      <xsl:choose>
        <xsl:when test="$COLLAPSE_LABEL != ''"><xsl:value-of select="$COLLAPSE_LABEL"/></xsl:when>
        <xsl:otherwise>Collapse all</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>
    <xsl:variable name="HEADER_ALIGN_RAW" select="normalize-space(//Datum[@ID='HeaderAlignment']/text()[last()])"/>
    <xsl:variable name="HEADER_ALIGN">
      <xsl:choose>
        <xsl:when test="$HEADER_ALIGN_RAW = 'center'">center</xsl:when>
        <xsl:otherwise>left</xsl:otherwise>
      </xsl:choose>
    </xsl:variable>

    <xsl:variable name="TITLE_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$TITLE_TAG_RAW"/>
        <xsl:with-param name="default" select="'h2'"/>
      </xsl:call-template>
    </xsl:variable>
    <xsl:variable name="DESC_TAG">
      <xsl:call-template name="pickTag">
        <xsl:with-param name="raw" select="$DESC_TAG_RAW"/>
        <xsl:with-param name="default" select="'p'"/>
      </xsl:call-template>
    </xsl:variable>

    <!-- ==== Stylesheet hoist ==== -->
    <xsl:if test="$CSS_PATH != ''">
      <link rel="stylesheet" type="text/css">
        <xsl:attribute name="href">
          <xsl:value-of select="$CSS_PATH"/>
          <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
        </xsl:attribute>
      </link>
    </xsl:if>

    <!-- ==== Preset routing ==== -->
    <xsl:choose>

      <xsl:when test="$PRESET = 'strategy-and-economics-notes'">

        <section>
          <xsl:attribute name="class">rbccm-accordions rbccm-accordions--strategy-and-economics-notes<xsl:if test="$HEADER_ALIGN = 'center'"> rbccm-accordions--header-center</xsl:if></xsl:attribute>
          <xsl:if test="$SECTION_ID != ''">
            <xsl:attribute name="id"><xsl:value-of select="$SECTION_ID"/></xsl:attribute>
          </xsl:if>
          <xsl:if test="$SECTION_ARIA != ''">
            <xsl:attribute name="aria-label"><xsl:value-of select="$SECTION_ARIA"/></xsl:attribute>
          </xsl:if>

          <div class="rbccm-accordions__container">

            <!-- Section header -->
            <div class="rbccm-accordions__header">
              <div class="rbccm-accordions__header-lede">
                <xsl:if test="$TITLE_TEXT != ''">
                  <xsl:element name="{$TITLE_TAG}">
                    <xsl:attribute name="class">rbccm-accordions__title</xsl:attribute>
                    <!-- Scroll-triggered reveal driven by rbccm-animate/rbccm-animate.js.
                         Runtime injects opacity:0 pre-state; IntersectionObserver plays
                         the animate.css class when the element enters the viewport. -->
                    <xsl:attribute name="data-animate">fadeInUp</xsl:attribute>
                    <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$TITLE_TEXT"/></xsl:call-template>
                  </xsl:element>
                </xsl:if>
                <xsl:variable name="HAS_DESC"><xsl:call-template name="hasText"><xsl:with-param name="s" select="$DESC_TEXT"/></xsl:call-template></xsl:variable>
                <xsl:if test="$HAS_DESC = 'yes'">
                  <xsl:element name="{$DESC_TAG}">
                    <xsl:attribute name="class">rbccm-accordions__description</xsl:attribute>
                    <xsl:attribute name="data-animate">fadeInUp</xsl:attribute>
                    <xsl:attribute name="data-animate-delay">250</xsl:attribute>
                    <xsl:call-template name="rbccmRich"><xsl:with-param name="s" select="$DESC_TEXT"/></xsl:call-template>
                  </xsl:element>
                </xsl:if>
              </div>
              <!-- Always rendered, whatever else is blank. Blank labels fall
                   back to "Expand all" / "Collapse all". -->
              <button type="button" class="rbccm-accordions__expand-all" data-accordions-expand-all="" aria-expanded="false" data-animate="fadeIn" data-animate-delay="500">
                <xsl:attribute name="data-label-expand"><xsl:value-of select="$EXPAND_TEXT"/></xsl:attribute>
                <xsl:attribute name="data-label-collapse"><xsl:value-of select="$COLLAPSE_TEXT"/></xsl:attribute>
                <xsl:value-of select="$EXPAND_TEXT"/>
              </button>
            </div>

            <!-- Note list. data-stagger-parent lets rbccm-animate.js reveal
                 direct children one after another with a fixed step. -->
            <div class="rbccm-accordions__list" data-stagger-parent="fadeInUp" data-stagger-step="160">

              <!-- Loop over 8 slots. Each slot's Datums are read fresh
                   inside a call-template; xsl:call-template with
                   per-slot lookups keeps the template body generic. -->
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="1"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="2"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="3"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="4"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="5"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="6"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="7"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>
              <xsl:call-template name="renderSlot"><xsl:with-param name="n" select="8"/><xsl:with-param name="sid" select="$SECTION_ID"/></xsl:call-template>

            </div>
          </div>
        </section>

        <xsl:if test="$JS_PATH != ''">
          <script>
            <xsl:attribute name="src">
              <xsl:value-of select="$JS_PATH"/>
              <xsl:if test="$CACHE_VERSION != ''">?v=<xsl:value-of select="$CACHE_VERSION"/></xsl:if>
            </xsl:attribute>
          </script>
        </xsl:if>

      </xsl:when>

      <xsl:otherwise/>
    </xsl:choose>

  </xsl:template>

  <!-- Per-slot lookup + renderNote dispatcher. Reads Datums named
       Item{N}FieldName using concat(). XSL 1.0 safe. -->
  <xsl:template name="renderSlot">
    <xsl:param name="n"/>
    <xsl:param name="sid"/>
    <xsl:variable name="cat"      select="normalize-space(//Datum[@ID=concat('Item', $n, 'CategoryText')]/text()[last()])"/>
    <xsl:variable name="titleCheck" select="normalize-space(//Datum[@ID=concat('Item', $n, 'TitleText')]/text()[last()])"/>
    <!-- A slot renders when it has a category or a title, so a blank
         category only hides the eyebrow, not the whole note. -->
    <xsl:if test="$cat != '' or $titleCheck != ''">
      <xsl:variable name="catTagRaw"     select="normalize-space(//Datum[@ID=concat('Item', $n, 'CategoryTag')]/text()[last()])"/>
      <xsl:variable name="author"        select="normalize-space(//Datum[@ID=concat('Item', $n, 'Author')]/text()[last()])"/>
      <xsl:variable name="date"          select="normalize-space(//Datum[@ID=concat('Item', $n, 'Date')]/text()[last()])"/>
      <xsl:variable name="titleText"     select="normalize-space(//Datum[@ID=concat('Item', $n, 'TitleText')]/text()[last()])"/>
      <xsl:variable name="titleTagRaw"   select="normalize-space(//Datum[@ID=concat('Item', $n, 'TitleTag')]/text()[last()])"/>
      <xsl:variable name="summaryText"   select="//Datum[@ID=concat('Item', $n, 'SummaryText')]"/>
      <xsl:variable name="summaryTagRaw" select="normalize-space(//Datum[@ID=concat('Item', $n, 'SummaryTag')]/text()[last()])"/>
      <xsl:variable name="bodyHtml"      select="//Datum[@ID=concat('Item', $n, 'BodyHtml')]"/>
      <xsl:variable name="rmLabel"       select="normalize-space(//Datum[@ID=concat('Item', $n, 'ReadMoreLabel')]/text()[last()])"/>
      <xsl:variable name="rmHref"        select="normalize-space(//Datum[@ID=concat('Item', $n, 'ReadMoreHref')]/text()[last()])"/>
      <xsl:variable name="rmAria"        select="normalize-space(//Datum[@ID=concat('Item', $n, 'ReadMoreAria')]/text()[last()])"/>

      <xsl:variable name="catTag">
        <xsl:call-template name="pickTag">
          <xsl:with-param name="raw" select="$catTagRaw"/>
          <xsl:with-param name="default" select="'p'"/>
        </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="titleTag">
        <xsl:call-template name="pickTag">
          <xsl:with-param name="raw" select="$titleTagRaw"/>
          <xsl:with-param name="default" select="'h3'"/>
        </xsl:call-template>
      </xsl:variable>
      <xsl:variable name="summaryTag">
        <xsl:call-template name="pickTag">
          <xsl:with-param name="raw" select="$summaryTagRaw"/>
          <xsl:with-param name="default" select="'p'"/>
        </xsl:call-template>
      </xsl:variable>

      <xsl:call-template name="renderNote">
        <xsl:with-param name="idx" select="$n"/>
        <xsl:with-param name="sectionId" select="$sid"/>
        <xsl:with-param name="categoryText" select="$cat"/>
        <xsl:with-param name="categoryTag" select="$catTag"/>
        <xsl:with-param name="author" select="$author"/>
        <xsl:with-param name="date" select="$date"/>
        <xsl:with-param name="titleText" select="$titleText"/>
        <xsl:with-param name="titleTag" select="$titleTag"/>
        <xsl:with-param name="summaryText" select="$summaryText"/>
        <xsl:with-param name="summaryTag" select="$summaryTag"/>
        <xsl:with-param name="bodyHtml" select="$bodyHtml"/>
        <xsl:with-param name="readMoreLabel" select="$rmLabel"/>
        <xsl:with-param name="readMoreHref" select="$rmHref"/>
        <xsl:with-param name="readMoreAria" select="$rmAria"/>
      </xsl:call-template>
    </xsl:if>
  </xsl:template>

</xsl:stylesheet>
