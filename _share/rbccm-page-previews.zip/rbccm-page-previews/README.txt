RBCCM page previews
===================

Built previews of four rbccm.com pages, plus the component inventory.

How to open
-----------
The pages load images, videos and sample data from this folder, so open
them through a small local server rather than double-clicking the files.

1. Open a terminal in this folder (the one with index.html).
2. Run:   npx http-server . -p 8743 -c-1
   (needs Node.js: https://nodejs.org)
3. Go to http://localhost:8743/ and pick a page.

Stop the server with Ctrl+C. If port 8743 is busy, use another number
(e.g. 8745) in both the command and the address.

What's inside
-------------
index.html            list of the pages
dist/<page>.html      the page previews
dist/css, dist/js     each page's bundled CSS and JS
dist/inventory.html   which components each page uses
rbccm-*/, filtered-content/, maas-mata-page/
                      the images, videos and sample feeds the pages use

ETF Innovators is not live yet: the host headshot and the two story
images are placeholders.
